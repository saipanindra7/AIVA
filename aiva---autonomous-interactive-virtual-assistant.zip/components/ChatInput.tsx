
import React, { useState, useRef, useEffect, KeyboardEvent } from 'react';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  disabled: boolean; // General disable, e.g. while AIVA is thinking
  isRecording: boolean;
  startRecording: () => void;
  stopRecording: () => void;
  sttError: string | null;
  setSttError: (error: string | null) => void;
  sttTranscript: string;
  setSttTranscript: (transcript: string) => void;
  isSttSupported: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ 
  onSendMessage, 
  disabled,
  isRecording,
  startRecording,
  stopRecording,
  sttError,
  setSttError,
  sttTranscript,
  setSttTranscript,
  isSttSupported
}) => {
  const [text, setText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (sttTranscript) {
      setText(sttTranscript); // Update text area with transcript
    }
  }, [sttTranscript]);
  
  // Clear STT transcript from input if user types manually
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
    if(isRecording) stopRecording(); // Stop recording if user types
    if(sttTranscript && e.target.value !== sttTranscript) {
        setSttTranscript(''); // Clear transcript if user edits it
    }
    if (sttError) setSttError(null); // Clear STT error on type
  };

  const handleSubmit = () => {
    const messageToSend = text.trim();
    if (messageToSend && !disabled) {
      onSendMessage(messageToSend);
      setText('');
      setSttTranscript(''); // Clear transcript after sending
      if (sttError) setSttError(null);
    }
  };

  const handleKeyPress = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSubmit();
    }
  };
  
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${scrollHeight}px`;
    }
  }, [text]);

  const toggleRecording = () => {
    if (!isSttSupported) {
      setSttError("Voice input is not supported by your browser.");
      return;
    }
    if (isRecording) {
      stopRecording();
    } else {
      setSttError(null); // Clear previous errors
      setText(''); // Clear text area before starting new recording
      setSttTranscript('');
      startRecording();
    }
  };

  const MicIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
      <path d="M12 18.75a6 6 0 006-6v-1.5a.75.75 0 00-1.5 0v1.5a4.5 4.5 0 11-9 0v-1.5a.75.75 0 00-1.5 0v1.5a6 6 0 006 6z" />
      <path d="M12 15a3 3 0 01-3-3V4.5a3 3 0 016 0V12a3 3 0 01-3 3z" />
    </svg>
  );

  const StopIcon = () => ( // Simple square for stop
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
      <path fillRule="evenodd" d="M4.5 7.5a3 3 0 013-3h9a3 3 0 013 3v9a3 3 0 01-3 3h-9a3 3 0 01-3-3v-9z" clipRule="evenodd" />
    </svg>
  );

  return (
    <div className="flex-1 flex items-end bg-gray-700 bg-opacity-75 rounded-lg p-1 focus-within:ring-2 focus-within:ring-purple-500 transition-shadow shadow-sm">
      <textarea
        ref={textareaRef}
        value={text}
        onChange={handleTextChange}
        onKeyPress={handleKeyPress}
        placeholder={isRecording ? "Listening..." : "Type or click mic to talk..."}
        className="flex-1 p-3 bg-transparent text-gray-200 placeholder-gray-400 focus:outline-none resize-none overflow-y-auto max-h-40 scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-700"
        rows={1}
        disabled={disabled || isRecording} // Disable typing while actively recording if STT directly fills it
        style={{ scrollPaddingBlockEnd: '8px' }}
      />
      {isSttSupported && (
        <button
          onClick={toggleRecording}
          disabled={disabled} // General disable from parent
          className={`p-3 text-white rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-purple-400 disabled:opacity-60 disabled:cursor-not-allowed mx-2 flex-shrink-0 aspect-square flex items-center justify-center ${
            isRecording ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-green-600 hover:bg-green-700'
          }`}
          title={isRecording ? "Stop Recording" : "Start Voice Input"}
        >
          {isRecording ? <StopIcon /> : <MicIcon />}
        </button>
      )}
      <button
        onClick={handleSubmit}
        disabled={disabled || !text.trim() || isRecording}
        className="p-3 bg-purple-600 hover:bg-purple-700 text-white rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-purple-400 disabled:opacity-60 disabled:cursor-not-allowed flex-shrink-0 aspect-square flex items-center justify-center"
        title="Send Message"
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
          <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
        </svg>
      </button>
    </div>
  );
};

export default ChatInput;
