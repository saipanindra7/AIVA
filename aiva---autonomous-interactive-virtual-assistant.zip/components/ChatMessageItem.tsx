
import React from 'react';
import { ChatMessage, MessageSender } from '../types';
import SourcePill from './SourcePill';
import { marked } from 'marked';

interface ChatMessageItemProps {
  message: ChatMessage;
  onPlayAudio?: (text: string) => void;
  isTtsSupported?: boolean;
}

marked.setOptions({
  breaks: true,
  gfm: true,
});

const SpeakerIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-4 h-4 ${className}`}>
    <path fillRule="evenodd" d="M9.974 7.044A.75.75 0 0111.25 7.5v9a.75.75 0 01-1.276.546L6.962 13.5H4.5a.75.75 0 01-.75-.75v-3a.75.75 0 01.75-.75h2.462l3.012-3.456zM13.5 8.25a.75.75 0 01.75.75v6a.75.75 0 01-.75.75h-.75a.75.75 0 01-.75-.75V9a.75.75 0 01.75-.75h.75zM15.75 6.75a.75.75 0 01.75.75v9a.75.75 0 01-.75.75h-.75a.75.75 0 01-.75-.75v-9a.75.75 0 01.75-.75h.75zM18 5.25a.75.75 0 01.75.75v12a.75.75 0 01-.75.75h-.75a.75.75 0 01-.75-.75V6a.75.75 0 01.75-.75h.75z" clipRule="evenodd" />
  </svg>
);


const ChatMessageItem: React.FC<ChatMessageItemProps> = ({ message, onPlayAudio, isTtsSupported }) => {
  const isUser = message.sender === MessageSender.USER;
  const bubbleClasses = isUser
    ? 'bg-purple-600 text-white self-end rounded-l-xl rounded-tr-xl'
    : 'bg-gray-700 text-gray-200 self-start rounded-r-xl rounded-tl-xl';
  
  const formattedText = React.useMemo(() => {
    try {
      return marked.parse(message.text || "") as string;
    } catch (e) {
      console.error("Markdown parsing error:", e);
      return message.text.replace(/\n/g, '<br />');
    }
  }, [message.text]);

  const handlePlayAudio = () => {
    if (onPlayAudio && message.text) {
      onPlayAudio(message.text);
    }
  };

  return (
    <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} group`}>
      <div className={`relative max-w-xl md:max-w-2xl lg:max-w-3xl p-3 md:p-4 shadow-md ${bubbleClasses}`}>
        <div className="prose prose-sm prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: formattedText }} />
        
        {!isUser && isTtsSupported && onPlayAudio && (
          <button
            onClick={handlePlayAudio}
            className="absolute top-1 right-1 p-1 text-gray-400 hover:text-gray-200 transition-colors opacity-50 group-hover:opacity-100"
            title="Play message audio"
            aria-label="Play message audio"
          >
            <SpeakerIcon />
          </button>
        )}

        {message.sources && message.sources.length > 0 && (
          <div className="mt-3 pt-2 border-t border-gray-600">
            <p className="text-xs text-gray-400 mb-1">Sources:</p>
            <div className="flex flex-wrap gap-2">
              {message.sources.map((source, index) => (
                <SourcePill key={index} source={source} />
              ))}
            </div>
          </div>
        )}
      </div>
      <p className={`text-xs text-gray-500 mt-1 px-1 ${isUser ? 'text-right' : 'text-left'}`}>
        {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
      </p>
    </div>
  );
};

export default ChatMessageItem;
