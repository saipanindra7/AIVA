import React, { useEffect, useRef } from 'react';
// import { useAivaChat } from '../hooks/useAivaChat'; // No longer directly using the hook here
import { ChatMessage, MessageSender } from '../types'; // Import necessary types
import ChatMessageItem from './ChatMessageItem';
import ChatInput from './ChatInput';
import LoadingSpinner from './LoadingSpinner';

// Define props for ChatWindow explicitly
interface ChatWindowProps {
  messages: ChatMessage[];
  sendMessage: (text: string) => Promise<void>;
  isLoading: boolean;
  error: string | null;
  clearChat: () => void;
  isRecording: boolean;
  startRecording: () => void;
  stopRecording: () => void;
  sttError: string | null;
  setSttError: (error: string | null) => void;
  sttTranscript: string;
  setSttTranscript: (transcript: string) => void;
  isSttSupported: boolean;
  playMessageAudio: (text: string) => void;
  // cancelTts: () => void; // Included if needed by ChatInput or ChatMessageItem
  isTtsSupported: boolean;
}

const NO_SPEECH_DETECTED_MESSAGE = "No speech detected. Click the mic icon to try again.";


const ChatWindow: React.FC<ChatWindowProps> = ({
  messages, 
  sendMessage, 
  isLoading, 
  error: apiError, 
  clearChat,
  isRecording,
  startRecording,
  stopRecording,
  sttError,
  setSttError,
  sttTranscript,
  setSttTranscript,
  isSttSupported,
  playMessageAudio,
  isTtsSupported,
}) => {
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
      if (sttError && (isLoading || messages.some(m => m.sender === MessageSender.USER && m.timestamp.getTime() > (Date.now() - 5000)) )) {
        //   setSttError(null); 
      }
  }, [isLoading, messages, sttError, setSttError]);


  return (
    <div className="flex-1 flex flex-col overflow-hidden p-4 md:p-6 space-y-4">
      <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-850 rounded-lg">
        {messages.map((msg) => (
          <ChatMessageItem 
            key={msg.id} 
            message={msg}
            onPlayAudio={playMessageAudio}
            isTtsSupported={isTtsSupported}
          />
        ))}
        {isLoading && messages.length > 0 && messages[messages.length -1].sender === MessageSender.USER && (
          <div className="flex items-center py-2 pl-2">
            <LoadingSpinner />
            <span className="ml-3 text-sm text-gray-400">AIVA is thinking...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      <div className="mt-auto p-1 bg-black bg-opacity-30 backdrop-blur-sm rounded-lg shadow-md">
        {(apiError && !isLoading) && <div className="text-red-400 p-2 text-xs text-center rounded bg-red-900 bg-opacity-50 mb-2 mx-1">API Error: {apiError}</div>}
        
        {(sttError && !isRecording) && (
          <div className={`p-2 text-xs text-center rounded bg-opacity-50 mb-2 mx-1 ${
            sttError === NO_SPEECH_DETECTED_MESSAGE
              ? 'text-gray-300 bg-gray-800' // More neutral styling for no-speech
              : 'text-yellow-400 bg-yellow-900' // Standard error styling
          }`}>
            {sttError === NO_SPEECH_DETECTED_MESSAGE
              ? sttError // Display message directly without "Voice Input Error:" prefix
              : `Voice Input Error: ${sttError}`} 
          </div>
        )}

        {!isSttSupported && <div className="text-yellow-500 p-2 text-xs text-center rounded bg-yellow-900 bg-opacity-30 mb-2 mx-1">Voice input (STT) is not supported in this browser.</div>}
        {!isTtsSupported && messages.length > 0 && <div className="text-yellow-500 p-2 text-xs text-center rounded bg-yellow-900 bg-opacity-30 mb-2 mx-1">Voice output (TTS) is not supported in this browser.</div>}

        <div className="flex items-end space-x-2 p-2">
          <ChatInput 
            onSendMessage={sendMessage} 
            disabled={isLoading}
            isRecording={isRecording}
            startRecording={startRecording}
            stopRecording={stopRecording}
            sttError={sttError}
            setSttError={setSttError}
            sttTranscript={sttTranscript}
            setSttTranscript={setSttTranscript}
            isSttSupported={isSttSupported}
          />
          <button
            onClick={clearChat}
            disabled={isLoading || isRecording}
            className="p-3 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-red-400 disabled:opacity-60 disabled:cursor-not-allowed flex-shrink-0 aspect-square flex items-center justify-center"
            title="Clear Chat History & Start New Session"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;