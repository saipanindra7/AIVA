
import React from 'react';
import { GroundingSource } from '../types';

interface SourcePillProps {
  source: GroundingSource;
}

const SourcePill: React.FC<SourcePillProps> = ({ source }) => {
  return (
    <a
      href={source.uri}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-600 text-gray-200 hover:bg-gray-500 transition-colors duration-150 truncate"
      title={source.title || source.uri}
    >
      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1.5 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0l-.01-.01L8.56 11.434a1 1 0 01-1.414-1.414l3.01-3.01a2 2 0 012.828 0zM5.414 11.414a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0l-.01-.01L3.56 15.434a1 1 0 01-1.414-1.414l3.01-3.01a2 2 0 012.828 0zM10 12a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
      </svg>
      <span className="truncate">{source.title || new URL(source.uri).hostname}</span>
    </a>
  );
};

export default SourcePill;
