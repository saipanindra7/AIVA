
import React, { useEffect, useState, useMemo } from 'react';
import { AvatarStyle, UserMood } from '../types';

interface AvatarDisplayProps {
  isTalking: boolean;
  avatarStyle: AvatarStyle;
  userMood: UserMood;
}

// --- Helper to lighten/darken hex colors ---
function adjustColor(color: string, amount: number): string {
  let usePound = false;
  if (color[0] === "#") {
    color = color.slice(1);
    usePound = true;
  }
  const num = parseInt(color, 16);
  let r = (num >> 16) + amount;
  if (r > 255) r = 255; else if (r < 0) r = 0;
  let b = ((num >> 8) & 0x00FF) + amount;
  if (b > 255) b = 255; else if (b < 0) b = 0;
  let g = (num & 0x0000FF) + amount;
  if (g > 255) g = 255; else if (g < 0) g = 0;
  const newColor = "000000" + (g | (b << 8) | (r << 16)).toString(16);
  return (usePound ? "#" : "") + newColor.slice(-6);
}

// --- VirtualCharacterHumanoid Component (Final Polish for Hyper-Realism) ---
interface VirtualCharacterHumanoidProps {
  className?: string;
  mood?: UserMood;
  isTalking?: boolean;
  skinBase: string; skinShadowLight: string; skinShadowMedium: string; skinShadowDeep: string; skinHighlight: string; skinPoreColor: string; skinUndertone: string; skinBlushColor: string;
  lipBase: string; lipHighlight: string; lipVermillionBorder: string; lipInnerEdge: string; lipGlossHighlight: string;
  hairBase: string; hairHighlightPrimary: string; hairHighlightSecondary: string; hairShadowPrimary: string; hairShadowSecondary: string; hairFlyawayColor: string; hairRootColor: string; hairShadowDeep: string;
  irisBase: string; irisAccent1: string; irisAccent2: string; irisLimbalRing: string; irisHighlightColor: string; irisShadow: string; irisPatternColor: string;
  scleraBase: string; scleraVeinColor: string; scleraShadow: string; scleraHighlight: string;
  lashLineColor: string; eyebrowColor: string; eyebrowStrokeColor: string;
  innerMouthColor: string; tongueColor: string; teethBaseColor: string; teethHighlightColor: string; gumColor: string;
  clothingBaseColor: string; clothingHighlightColor: string; clothingShadowColor: string; clothingTextureColor: string; clothingAccentColor: string;
  personaFeatures: {
    eyeShapePreset: 'almond' | 'round' | 'upturned' | 'monolid';
    noseShapePreset: 'straight' | 'button' | 'hooked' | 'aquiline';
    lipShapePreset: 'full' | 'thin' | 'bow' | 'medium' | 'heart';
    faceShapePath: string; // Defines unique head contour
    hairStylePaths: { main: string; highlights: string[]; shadows: string[]; flyaways?: string; roots?: string; strandDetails?: string[]; };
    earShapePath: string; // Defines unique ear contour
  };
}

const VirtualCharacterHumanoid: React.FC<VirtualCharacterHumanoidProps> = ({
  className = "w-48 h-48", mood, isTalking, personaFeatures, ...colors
}) => {
  const [blinkPhase, setBlinkPhase] = useState(0); // 0:open, 1:closing, 2:closed, 3:opening
  const [doubleBlinkNext, setDoubleBlinkNext] = useState(false);
  const [eyeDartX, setEyeDartX] = useState(0);
  const [eyeDartY, setEyeDartY] = useState(0);
  const [saccadeTargetX, setSaccadeTargetX] = useState(0);
  const [saccadeTargetY, setSaccadeTargetY] = useState(0);
  const [idleHeadTilt, setIdleHeadTilt] = useState(0);
  const [idleHeadBob, setIdleHeadBob] = useState(0);
  const [idleHeadRotateZ, setIdleHeadRotateZ] = useState(0);
  const [breathingScale, setBreathingScale] = useState(1);
  const [browFurrow, setBrowFurrow] = useState(0); 
  const [cheekRaise, setCheekRaise] = useState(0); 
  const [lipCornerPull, setLipCornerPull] = useState(0); 
  const [jawDrop, setJawDrop] = useState(0); 
  const [nostrilFlare, setNostrilFlare] = useState(0);
  const [eyelidSquint, setEyelidSquint] = useState(0); // For subtle focus/emotion


  useEffect(() => { // Blinking Logic
    let blinkTimeoutId: number;
    const manageBlink = () => {
      if (blinkPhase === 0) {
        const delay = doubleBlinkNext ? (Math.random() * 50 + 50) : (Math.random() * 3500 + 2000);
        blinkTimeoutId = window.setTimeout(() => {
          setDoubleBlinkNext(Math.random() < 0.2);
          setBlinkPhase(1);
        }, delay);
      } else if (blinkPhase === 1) { // Closing
        blinkTimeoutId = window.setTimeout(() => setBlinkPhase(2), 60 + Math.random()*20); 
      } else if (blinkPhase === 2) { // Closed
        blinkTimeoutId = window.setTimeout(() => setBlinkPhase(3), doubleBlinkNext ? (50 + Math.random()*20) : (Math.random() * 50 + 80));
      } else if (blinkPhase === 3) { // Opening
        blinkTimeoutId = window.setTimeout(() => setBlinkPhase(0), 60 + Math.random()*20);
      }
    };
    manageBlink();
    return () => clearTimeout(blinkTimeoutId);
  }, [blinkPhase, doubleBlinkNext]);

  useEffect(() => { // Eye Saccades Logic
    const dartInterval = setInterval(() => {
        setSaccadeTargetX((Math.random() - 0.5) * 2.5); 
        setSaccadeTargetY((Math.random() - 0.5) * 2.0);
    }, Math.random() * 1200 + 1800);
    return () => clearInterval(dartInterval);
  }, []);

  useEffect(() => { // Smooth eye dart interpolation
    const easeFactor = 0.08;
    let animationFrameId: number;
    const updateDartPosition = () => {
      setEyeDartX(prev => prev + (saccadeTargetX - prev) * easeFactor);
      setEyeDartY(prev => prev + (saccadeTargetY - prev) * easeFactor);
      animationFrameId = requestAnimationFrame(updateDartPosition);
    };
    animationFrameId = requestAnimationFrame(updateDartPosition);
    return () => cancelAnimationFrame(animationFrameId);
  }, [saccadeTargetX, saccadeTargetY]);

  useEffect(() => { // Idle Head & Breathing Animations
    const idleMoveTimer = setInterval(() => {
      setIdleHeadTilt((Math.random() - 0.5) * 1.5);
      setIdleHeadBob((Math.random() - 0.5) * 0.25);
      setIdleHeadRotateZ((Math.random() - 0.5) * 0.8);
    }, 3500 + Math.random()*1000);
    const breathingTimer = setInterval(() => {
        setBreathingScale(1 + (Math.sin(Date.now() / 2000) * 0.0025)); // Slower, more subtle breathing
    }, 40);
    return () => { clearInterval(idleMoveTimer); clearInterval(breathingTimer); };
  }, []);

  useEffect(() => { // Micro-expressions based on mood
    setBrowFurrow(0); setCheekRaise(0); setLipCornerPull(0); setJawDrop(0); setNostrilFlare(0); setEyelidSquint(0);
    switch (mood) {
      case 'happy':
        setLipCornerPull(0.7 + Math.random() * 0.3);
        setCheekRaise(0.5 + Math.random() * 0.3);
        setEyelidSquint(0.3 + Math.random() * 0.2); // Eyes slightly crinkle
        break;
      case 'sad':
        setLipCornerPull(-0.6 - Math.random() * 0.3);
        setBrowFurrow(0.6 + Math.random() * 0.2); // Inner brows up, slight downward pull outer
        setJawDrop(0.1 + Math.random()*0.1); // Slight jaw drop
        setEyelidSquint(-0.2); // Eyes slightly wider or droopy
        break;
      case 'surprised':
        setBrowFurrow(-0.9 - Math.random() * 0.2); // Raise brows high
        setJawDrop(0.5 + Math.random() * 0.2);
        setEyelidSquint(-0.4); // Eyes wide
        break;
      default: // Neutral
        break;
    }
  }, [mood]);

  // Lip-syncing logic (highly complex, many visemes)
  const talkCycle = Date.now() % 1800; // Cycle for various mouth shapes
  let mouthPathUpper = `M38 ${72 + lipCornerPull*2} Q50 ${71 + lipCornerPull*1.5 - jawDrop*0.5} 62 ${72 + lipCornerPull*2}`;
  let mouthPathLower = `M39 ${72.5 + lipCornerPull*2} Q50 ${73 + lipCornerPull*1.5 + jawDrop*0.5} 61 ${72.5 + lipCornerPull*2}`;
  let teethVisible = 'none'; let innerMouthVisible = false; let tongueVisible = false;

  if (isTalking) {
    // This is a placeholder for a much more complex viseme animation system.
    // A full implementation would map phonemes to specific mouth shapes.
    // For brevity, using a simplified cyclic animation.
    if (talkCycle < 100) { // Rest/Closed (m, p, b)
        mouthPathUpper = `M38 ${71.8 + lipCornerPull*2 - eyelidSquint*0.2} Q50 ${71.3 + lipCornerPull*1.5 - jawDrop*2 - eyelidSquint*0.2} 62 ${71.8 + lipCornerPull*2 - eyelidSquint*0.2}`;
        mouthPathLower = `M39 ${72.2 + lipCornerPull*2 + eyelidSquint*0.2} Q50 ${72.7 + lipCornerPull*1.5 - jawDrop*2 + eyelidSquint*0.2} 61 ${72.2 + lipCornerPull*2 + eyelidSquint*0.2}`;
    } else if (talkCycle < 250) { // Ah, Open
        mouthPathUpper = `M37 ${70 - jawDrop*4 + lipCornerPull*1.2 - eyelidSquint*0.5} Q50 ${68 - jawDrop*5 + lipCornerPull*0.8 - eyelidSquint*0.5} 63 ${70 - jawDrop*4 + lipCornerPull*1.2 - eyelidSquint*0.5}`;
        mouthPathLower = `M38 ${74 + jawDrop*2 + eyelidSquint*0.5} Q50 ${76 + jawDrop*3 + eyelidSquint*0.5} 62 ${74 + jawDrop*2 + eyelidSquint*0.5}`;
        innerMouthVisible = true; teethVisible = 'upper';
    } else if (talkCycle < 400) { // Ee, Ih (Wide)
        mouthPathUpper = `M36 ${71.5 + lipCornerPull*2.5 - eyelidSquint*0.3} Q50 ${70 + lipCornerPull*2 - jawDrop*3 - eyelidSquint*0.3} 64 ${71.5 + lipCornerPull*2.5 - eyelidSquint*0.3}`;
        mouthPathLower = `M37 ${73 + lipCornerPull*2.5 + eyelidSquint*0.3} Q50 ${74 + lipCornerPull*2 - jawDrop*3 + eyelidSquint*0.3} 63 ${73 + lipCornerPull*2.5 + eyelidSquint*0.3}`;
        innerMouthVisible = true; teethVisible = 'both';
    }  else if (talkCycle < 550) { // Oh, Oo (Round)
        mouthPathUpper = `M42 ${70 - jawDrop*2 + lipCornerPull*0.5 - eyelidSquint*0.4} C45 ${68 - jawDrop*3 - eyelidSquint*0.4}, 55 ${68 - jawDrop*3 - eyelidSquint*0.4}, 58 ${70 - jawDrop*2 + lipCornerPull*0.5 - eyelidSquint*0.4}`;
        mouthPathLower = `M42 ${73 + jawDrop + eyelidSquint*0.4} C45 ${75 + jawDrop*1.5 + eyelidSquint*0.4}, 55 ${75 + jawDrop*1.5 + eyelidSquint*0.4}, 58 ${73 + jawDrop + eyelidSquint*0.4}`;
        innerMouthVisible = true;
    } else if (talkCycle < 700) { // F, V (Upper teeth on lower lip)
        mouthPathUpper = `M38 ${70.5 + lipCornerPull*1.5 - jawDrop*2 - eyelidSquint*0.2} Q50 ${69.5 + lipCornerPull - jawDrop*2.5 - eyelidSquint*0.2} 62 ${70.5 + lipCornerPull*1.5 - jawDrop*2 - eyelidSquint*0.2}`;
        mouthPathLower = `M40 ${72.5 + jawDrop*0.5 + eyelidSquint*0.2} Q50 ${71.8 + jawDrop*0.5 + eyelidSquint*0.2} 60 ${72.5 + jawDrop*0.5 + eyelidSquint*0.2}`; // Lower lip pulled in
        teethVisible = 'upper'; innerMouthVisible = true;
    } else if (talkCycle < 850) { // L, T, D (Tongue near upper teeth)
        mouthPathUpper = `M39 ${71 - jawDrop*2 - eyelidSquint*0.3} Q50 ${70 - jawDrop*2.5 - eyelidSquint*0.3} 61 ${71 - jawDrop*2 - eyelidSquint*0.3}`;
        mouthPathLower = `M40 ${73.5 + jawDrop + eyelidSquint*0.3} Q50 ${74.5 + jawDrop*1.5 + eyelidSquint*0.3} 60 ${73.5 + jawDrop + eyelidSquint*0.3}`;
        innerMouthVisible = true; tongueVisible = true; teethVisible = 'upper';
    } else { // Transition to rest
      mouthPathUpper = `M38 ${71.8 + lipCornerPull*2 - eyelidSquint*0.2} Q50 ${70.8 + lipCornerPull*1.5 - jawDrop*1.5 - eyelidSquint*0.2} 62 ${71.8 + lipCornerPull*2 - eyelidSquint*0.2}`;
      mouthPathLower = `M39 ${72.7 + lipCornerPull*2 + eyelidSquint*0.2} Q50 ${73.2 + lipCornerPull*1.5 - jawDrop*1.5 + eyelidSquint*0.2} 61 ${72.7 + lipCornerPull*2 + eyelidSquint*0.2}`;
    }
  }
  
  // Eye rendering parameters
  const blinkProgress = blinkPhase === 1 ? 0.3 : (blinkPhase === 2 ? 1 : (blinkPhase === 3 ? 0.7 : 0)); // 0 open, 1 fully closed
  let leftEyeLidTopY = 42.5 - browFurrow*2 - cheekRaise*0.5 + eyelidSquint*1.5;
  let leftEyeLidBottomY = 47.5 + cheekRaise*1.5 - eyelidSquint*1.5;
  let rightEyeLidTopY = 42.5 - browFurrow*2 - cheekRaise*0.5 + eyelidSquint*1.5;
  let rightEyeLidBottomY = 47.5 + cheekRaise*1.5 - eyelidSquint*1.5;

  const pupilRadius = 1.7 + (mood === 'surprised' ? 0.5 : 0) - (mood === 'sad' ? 0.2 : 0) - eyelidSquint*0.1;

  // Eyebrow paths with more nuance based on browFurrow (positive=sad/angry, negative=surprised)
  const eyebrowLY = 35, eyebrowRY = 35;
  const eyebrowLCx = 35, eyebrowRCx = 65;
  // Sad/Angry: Inner part up/pinched, outer down. Surprised: All up.
  let eyebrowLeftPath = `M${25 - browFurrow*1.5} ${eyebrowLY + browFurrow*3} Q${eyebrowLCx - browFurrow*0.5} ${eyebrowLY - browFurrow*3.5 - Math.abs(browFurrow)*0.5} ${45 + browFurrow*1.5} ${eyebrowLY - browFurrow*2}`;
  let eyebrowRightPath = `M${55 - browFurrow*1.5} ${eyebrowRY - browFurrow*2} Q${eyebrowRCx + browFurrow*0.5} ${eyebrowRY - browFurrow*3.5 - Math.abs(browFurrow)*0.5} ${75 + browFurrow*1.5} ${eyebrowRY + browFurrow*3}`;

  const headTransform = `rotate(${isTalking ? (Math.sin(Date.now() / 380) * 1.0) : idleHeadTilt + idleHeadRotateZ*0.5} 50 55) translate(0, ${isTalking ? (Math.sin(Date.now() / 420) * 0.3) : idleHeadBob})`;
  const shoulderTransform = `scale(1, ${breathingScale}) translate(0, ${(1-breathingScale)*70 + (isTalking ? (Math.sin(Date.now() / 420) * 0.3)*0.2 : idleHeadBob*0.2)})`;

  const {
    skinBase, skinShadowLight, skinShadowMedium, skinShadowDeep, skinHighlight, skinPoreColor, skinUndertone, skinBlushColor,
    lipBase, lipHighlight, lipVermillionBorder, lipInnerEdge, lipGlossHighlight,
    hairBase, hairHighlightPrimary, hairHighlightSecondary, hairShadowPrimary, hairShadowSecondary, hairFlyawayColor, hairRootColor, hairShadowDeep,
    irisBase, irisAccent1, irisAccent2, irisLimbalRing, irisHighlightColor, irisShadow, irisPatternColor,
    scleraBase, scleraVeinColor, scleraShadow, scleraHighlight,
    lashLineColor, eyebrowColor, eyebrowStrokeColor,
    innerMouthColor, tongueColor, teethBaseColor, teethHighlightColor, gumColor,
    clothingBaseColor, clothingHighlightColor, clothingShadowColor, clothingTextureColor, clothingAccentColor,
  } = colors;

  const { hairStylePaths, faceShapePath, earShapePath } = personaFeatures;

  // This SVG structure is a highly simplified version of what would be needed. A full implementation is massive.
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" className={className}>
      <defs>
        {/* Countless gradients and patterns for skin, hair, eyes, lips, clothing */}
        <radialGradient id={`grad-skin-${skinBase.slice(1)}`} cx="50%" cy="40%" r="70%">
          <stop offset="0%" stopColor={skinHighlight} /> <stop offset="30%" stopColor={skinBase} /> <stop offset="65%" stopColor={skinShadowLight} /> <stop offset="85%" stopColor={skinShadowMedium} /><stop offset="100%" stopColor={skinShadowDeep} />
        </radialGradient>
        <radialGradient id={`grad-iris-${irisBase.slice(1)}`}>
          <stop offset="0%" stopColor={irisHighlightColor} /> <stop offset="15%" stopColor={irisAccent1} /> <stop offset="40%" stopColor={irisBase} /> <stop offset="70%" stopColor={irisAccent2} /> <stop offset="90%" stopColor={irisShadow} /> <stop offset="100%" stopColor={irisLimbalRing} />
        </radialGradient>
         <linearGradient id={`grad-lip-${lipBase.slice(1)}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={lipHighlight}/> <stop offset="40%" stopColor={lipBase}/> <stop offset="70%" stopColor={adjustColor(lipBase, -15)} /> <stop offset="100%" stopColor={adjustColor(lipBase, -25)} />
        </linearGradient>
        <pattern id={`skinPorePattern-${skinPoreColor.slice(1)}`} patternUnits="userSpaceOnUse" width="2" height="2">
            <circle cx="0.3" cy="0.3" r="0.15" fill={skinPoreColor} opacity="0.2"/> <circle cx="1.3" cy="1.3" r="0.15" fill={skinPoreColor} opacity="0.15"/>
        </pattern>
         <filter id="subtleBlur"><feGaussianBlur stdDeviation="0.15"/></filter>
         <filter id="softShadow"><feDropShadow dx="0.2" dy="0.4" stdDeviation="0.3" floodColor={skinShadowDeep} floodOpacity="0.3" /></filter>
         {/* Iris pattern */}
        <pattern id={`irisPattern-${irisPatternColor.slice(1)}`} patternUnits="userSpaceOnUse" width="1" height="10" patternTransform="rotate(45)">
            <line x1="0" y1="0" x2="0" y2="10" stroke={irisPatternColor} strokeWidth="0.1" opacity="0.4"/>
        </pattern>
      </defs>

      {/* Shoulders/Clothing (simplified) */}
      <g transform={shoulderTransform} filter="url(#softShadow)">
        <path d="M5 80 Q50 68 95 80 L90 100 L10 100 Z" fill={clothingBaseColor} />
        <path d="M5 80 Q50 68 95 80" stroke={clothingHighlightColor} strokeWidth="1" fill="none" opacity="0.5"/>
        <path d="M40 78 L60 78" stroke={clothingAccentColor} strokeWidth="2.5" />{/* E.g. a collar detail */}
         {/* Neck */}
        <path d="M44 70 Q50 65 56 70 L54 80 L46 80 Z" fill={`url(#grad-skin-${skinBase.slice(1)})`} />
        <path d="M44 70 Q50 65 56 70" stroke={skinShadowDeep} strokeWidth="0.25" fill="none"/>
      </g>

      <g transform={headTransform} filter="url(#softShadow)">
        {/* Face Shape from personaFeatures */}
        <path d={faceShapePath} fill={`url(#grad-skin-${skinBase.slice(1)})`} stroke={skinShadowMedium} strokeWidth="0.2" />
        <path d={faceShapePath} fill={`url(#skinPorePattern-${skinPoreColor.slice(1)})`} opacity="0.4" />
         {/* Blush */}
        <ellipse cx="30" cy="55" rx="8" ry="5" fill={skinBlushColor} opacity={mood==='happy'||mood==='surprised'?0.15:0.05} filter="url(#subtleBlur)"/>
        <ellipse cx="70" cy="55" rx="8" ry="5" fill={skinBlushColor} opacity={mood==='happy'||mood==='surprised'?0.15:0.05} filter="url(#subtleBlur)"/>

        {/* Hair (simplified) */}
        <g id="hair-group">
          {hairStylePaths.roots && <path d={hairStylePaths.roots} fill={hairRootColor} opacity="0.7"/>}
          <path d={hairStylePaths.main} fill={hairBase} />
          {hairStylePaths.shadows.map((p, i) => <path key={`hsh-${i}`} d={p} fill={hairShadowPrimary} opacity="0.6" />)}
          {hairStylePaths.highlights.map((p, i) => <path key={`hhl-${i}`} d={p} fill={hairHighlightPrimary} opacity="0.5" filter="url(#subtleBlur)"/>)}
          {hairStylePaths.strandDetails?.map((p, i) => <path key={`hsd-${i}`} d={p} stroke={hairHighlightSecondary} strokeWidth="0.2" fill="none" opacity="0.6"/>)}
          {hairStylePaths.flyaways && <path d={hairStylePaths.flyaways} stroke={hairFlyawayColor} strokeWidth="0.15" fill="none" opacity="0.7"/>}
        </g>
        
        {/* Ears from personaFeatures (simplified) */}
        <path d={personaFeatures.earShapePath.replace(/M(\d+)/, `M${parseFloat(RegExp.$1)-0.5}`)} fill={skinShadowLight} />{/* Left Ear Shadow*/}
        <path d={personaFeatures.earShapePath} fill={skinBase} stroke={skinShadowMedium} strokeWidth="0.15"/> {/* Left Ear */}
        <path d={personaFeatures.earShapePath.replace(/M(\d+)/, `M${100-parseFloat(RegExp.$1)+0.5}`)} fill={skinShadowLight} transform="scale(-1, 1) translate(-100, 0)"/>{/* Right Ear Shadow*/}
        <path d={personaFeatures.earShapePath.replace(/M(\d+)/, `M${100-parseFloat(RegExp.$1)}`)} fill={skinBase} stroke={skinShadowMedium} strokeWidth="0.15" transform="scale(-1, 1) translate(-100, 0)"/> {/* Right Ear */}


        {/* Nose (simplified) */}
        <path d={`M48.8 ${50-jawDrop*0.5} L51.2 ${50-jawDrop*0.5} L50.5 58 L49.5 58 Z`} fill={skinShadowLight} opacity="0.7"/>
        <path d={`M49 ${50.5-jawDrop*0.5} L51 ${50.5-jawDrop*0.5}`} stroke={skinHighlight} strokeWidth="0.2" opacity="0.8"/>
        <path d={`M49 ${58} Q50 ${60 + nostrilFlare*0.5} 51 ${58} C 51.3 58.8, 48.7 58.8, 49 58 Z`} fill={skinShadowMedium} opacity="0.6"/>
        <ellipse cx={`47.8 - ${nostrilFlare*0.3}`} cy="59.5" rx={`${0.8 + nostrilFlare*0.2}`} ry="0.6" fill={skinShadowDeep} opacity="0.8"/>
        <ellipse cx={`52.2 + ${nostrilFlare*0.3}`} cy="59.5" rx={`${0.8 + nostrilFlare*0.2}`} ry="0.6" fill={skinShadowDeep} opacity="0.8"/>
        
        {/* Eyes (highly simplified rendering for brevity) */}
        {[
          { cx: 35, topY: leftEyeLidTopY, bottomY: leftEyeLidBottomY },
          { cx: 65, topY: rightEyeLidTopY, bottomY: rightEyeLidBottomY }
        ].map(eye => (
          <g key={`eye-${eye.cx}`} transform={`translate(${eyeDartX*0.7}, ${eyeDartY*0.7})`}>
            {/* Sclera */}
            <ellipse cx={eye.cx} cy="45" rx="7" ry={blinkPhase > 0 && blinkPhase < 3 ? 1.5 - blinkProgress*0.5 : 5.5 - eyelidSquint*0.8} fill={scleraBase} />
            <path d={`M${eye.cx-3} 44 q1 -0.3 2 -0.5 M${eye.cx+2} 46 q-0.8 0.2 -1.5 0.4`} stroke={scleraVeinColor} strokeWidth="0.1" fill="none" opacity={blinkPhase > 0 && blinkPhase < 3 ? 0 : 0.4}/>
            <ellipse cx={eye.cx} cy="45" rx="7" ry={blinkPhase > 0 && blinkPhase < 3 ? 1.5- blinkProgress*0.5 : 5.5- eyelidSquint*0.8} fill={scleraShadow} opacity="0.08" />
             {/* Iris & Pupil */}
            <ellipse cx={eye.cx} cy="45" rx="4" ry={blinkPhase > 0 && blinkPhase < 3 ? 0.8 - blinkProgress*0.3 : 3.8 - eyelidSquint*0.5} fill={`url(#grad-iris-${irisBase.slice(1)})`} />
            <ellipse cx={eye.cx} cy="45" rx="4" ry={blinkPhase > 0 && blinkPhase < 3 ? 0.8 - blinkProgress*0.3 : 3.8 - eyelidSquint*0.5} fill={`url(#irisPattern-${irisPatternColor.slice(1)})`} opacity="0.5"/>
            <circle cx={eye.cx} cy="45" r={blinkPhase > 0 && blinkPhase < 3 ? 0.5 - blinkProgress*0.2 : pupilRadius} fill={colors.irisShadow} />
            {/* Highlights */}
            {!(blinkPhase > 0 && blinkPhase < 3) && <>
              <circle cx={`${eye.cx - 1.2 + eyeDartX*0.05}`} cy={`${43.5 + eyeDartY*0.05}`} r="0.9" fill={irisHighlightColor} opacity="0.9"/>
              <ellipse cx={`${eye.cx + 0.8 + eyeDartX*0.02}`} cy={`${45.8 + eyeDartY*0.02}`} rx="0.35" ry="0.5" fill={irisHighlightColor} opacity="0.7"/>
              <line x1={eye.cx-6.5} y1={eye.bottomY} x2={eye.cx+6.5} y2={eye.bottomY} stroke={scleraHighlight} strokeWidth="0.25" opacity="0.5" />{/* Lower lid waterline */}
            </>}
            {/* Eyelids & Lashes (very simplified) */}
            <path d={`M${eye.cx-7.5} ${eye.topY} C${eye.cx-5} ${eye.topY - 2.5 - eyelidSquint*0.5}, ${eye.cx+5} ${eye.topY - 2.5 - eyelidSquint*0.5}, ${eye.cx+7.5} ${eye.topY}`} 
                  stroke={skinShadowMedium} fill={skinBase} strokeWidth="0.25" 
                  transform={`scale(1, ${blinkPhase === 1 ? 0.7 : (blinkPhase === 2 ? 0.1 : (blinkPhase === 3 ? 0.5 : 1))}) translate(0 ${blinkProgress * (45 - eye.topY)})`}
                  style={{transformOrigin: `${eye.cx}px ${eye.topY}px`}}/> {/* Upper Lid */}
            <path d={`M${eye.cx-7.5} ${eye.bottomY} C${eye.cx-5} ${eye.bottomY + 2 + eyelidSquint*0.5}, ${eye.cx+5} ${eye.bottomY + 2 + eyelidSquint*0.5}, ${eye.cx+7.5} ${eye.bottomY}`} 
                  stroke={skinShadowLight} fill={skinBase} strokeWidth="0.2" 
                  transform={`scale(1, ${blinkPhase === 1 ? 0.85 : (blinkPhase === 2 ? 0.6 : (blinkPhase === 3 ? 0.9 : 1))}) translate(0 ${-blinkProgress * (eye.bottomY - 45)})`}
                  style={{transformOrigin: `${eye.cx}px ${eye.bottomY}px`}}/> {/* Lower Lid */}
             {!(blinkPhase > 0 && blinkPhase < 3) && 
                <path d={`M${eye.cx-7} ${eye.topY-0.1} C${eye.cx-4.5} ${eye.topY - 0.3}, ${eye.cx+4.5} ${eye.topY - 0.3}, ${eye.cx+7} ${eye.topY-0.1}`} stroke={lashLineColor} fill="none" strokeWidth="0.3" />}
          </g>
        ))}

        {/* Eyebrows */}
        <path d={eyebrowLeftPath} stroke={eyebrowColor} strokeWidth="1.1" fill="none" strokeLinecap="round"/>
        <path d={eyebrowRightPath} stroke={eyebrowColor} strokeWidth="1.1" fill="none" strokeLinecap="round"/>
        {/* Philtrum and Cupid's bow are part of personaFeatures.faceShapePath or drawn over */}

        {/* Mouth (simplified) */}
        <g id="mouth-group">
          {innerMouthVisible && !(blinkPhase > 0 && blinkPhase < 3) &&
            <ellipse cx="50" cy={`${73.5 + jawDrop*1.5}`} rx={`${10 + jawDrop*1.5}`} ry={`${3.5 + jawDrop*2.5}`} fill={innerMouthColor} opacity="0.8" /> }
          {teethVisible !== 'none' && !(blinkPhase > 0 && blinkPhase < 3) &&
             <path d={`M40 ${71.0 - jawDrop*1.5} C42 ${70.0 - jawDrop*1.8}, 58 ${70.0 - jawDrop*1.8}, 60 ${71.0 - jawDrop*1.5} L59 ${72.5 - jawDrop*1.5} H41 Z`} fill={teethBaseColor}/>}
          <path d={mouthPathUpper} fill={`url(#grad-lip-${lipBase.slice(1)})`} stroke={lipVermillionBorder} strokeWidth="0.1"/>
          <path d={mouthPathLower} fill={`url(#grad-lip-${lipBase.slice(1)})`} stroke={lipVermillionBorder} strokeWidth="0.1"/>
          <ellipse cx="50" cy={71 + lipCornerPull*1.2 - jawDrop*0.8} rx="2.5" ry="0.8" fill={lipGlossHighlight} opacity={isTalking ? 0.3 : 0.5} filter="url(#subtleBlur)" />
        </g>
      </g>
    </svg>
  );
};


// --- Doraemon Avatar ---
const DoraemonAvatar: React.FC<{ mood?: UserMood; isTalking?: boolean; className?: string }> = ({ mood, isTalking, className="w-40 h-40" }) => {
  const eyeBaseY = 42;
  let eyeLeftX = 38, eyeRightX = 62;
  let pupilLeftX = eyeLeftX, pupilRightX = eyeRightX;
  let pupilY = eyeBaseY + 2;
  let mouthPath = "M 40 75 Q 50 80 60 75"; // Neutral
  let eyeShapeLeft = `M ${eyeLeftX-10} ${eyeBaseY} A 10 12 0 1 1 ${eyeLeftX+10} ${eyeBaseY} A 10 12 0 1 1 ${eyeLeftX-10} ${eyeBaseY}`; // Oval
  let eyeShapeRight = `M ${eyeRightX-10} ${eyeBaseY} A 10 12 0 1 1 ${eyeRightX+10} ${eyeBaseY} A 10 12 0 1 1 ${eyeRightX-10} ${eyeBaseY}`;
  let whiskerOpacity = 1;
  let mouthFill = "none";
  let showRedMouthInterior = false;

  if (mood === 'happy' || (isTalking && (Date.now() % 1000 < 500))) { // Happy or talking open mouth
    eyeShapeLeft = `M ${eyeLeftX-10} ${eyeBaseY+3} Q ${eyeLeftX} ${eyeBaseY-5}, ${eyeLeftX+10} ${eyeBaseY+3} Z`; // Upward curve
    eyeShapeRight = `M ${eyeRightX-10} ${eyeBaseY+3} Q ${eyeRightX} ${eyeBaseY-5}, ${eyeRightX+10} ${eyeBaseY+3} Z`;
    mouthPath = "M 35 72 C 35 85, 65 85, 65 72 Q 50 80 35 72 Z"; // Wide happy mouth
    showRedMouthInterior = true;
  } else if (mood === 'sad') {
    eyeShapeLeft = `M ${eyeLeftX-10} ${eyeBaseY-1} Q ${eyeLeftX} ${eyeBaseY+5}, ${eyeLeftX+10} ${eyeBaseY-1} Z`; // Downward curve, slightly droopy
    eyeShapeRight = `M ${eyeRightX-10} ${eyeBaseY-1} Q ${eyeRightX} ${eyeBaseY+5}, ${eyeRightX+10} ${eyeBaseY-1} Z`;
    mouthPath = "M 40 78 Q 50 72 60 78"; // Frown
    pupilY = eyeBaseY + 3;
  } else if (mood === 'surprised') {
    eyeShapeLeft = `M ${eyeLeftX-12} ${eyeBaseY} A 12 14 0 1 1 ${eyeLeftX+12} ${eyeBaseY} A 12 14 0 1 1 ${eyeLeftX-12} ${eyeBaseY}`; // Wider
    eyeShapeRight = `M ${eyeRightX-12} ${eyeBaseY} A 12 14 0 1 1 ${eyeRightX+12} ${eyeBaseY} A 12 14 0 1 1 ${eyeRightX-12} ${eyeBaseY}`;
    mouthPath = "M 45 70 A 6 9 0 1 0 55 70 A 6 9 0 1 0 45 70 Z"; // Open "O"
    showRedMouthInterior = true;
  } else { // Neutral or other talking phases
     mouthPath = "M 40 75 Q 50 80 60 75";
  }

  if (isTalking && !showRedMouthInterior) { // Simpler talking animation if not already handled by happy/surprised
    const talkCycle = Date.now() % 600;
    if (talkCycle < 200) mouthPath = "M 40 73 Q 50 78 60 73"; 
    else if (talkCycle < 400) mouthPath = "M 38 75 Q 50 82 62 75"; 
    else mouthPath = "M 42 72 Q 50 77 58 72"; 
    whiskerOpacity = 0.85 + Math.sin(Date.now()/120) * 0.15; 
  }


  return (
    <svg viewBox="0 0 100 100" className={className}>
      <defs>
        <radialGradient id="doraemonBlueGrad" cx="50%" cy="50%" r="60%">
          <stop offset="0%" stopColor="#39C2F7"/>
          <stop offset="100%" stopColor="#0077C5"/>
        </radialGradient>
         <radialGradient id="doraemonFaceGrad" cx="50%" cy="50%" r="50%">
          <stop offset="70%" stopColor="#FFFFFF"/>
          <stop offset="100%" stopColor="#F0F0F0"/>
        </radialGradient>
      </defs>
      {/* Body Hint (Shoulders) */}
      <path d="M10 90 Q50 75 90 90 L85 100 H15 Z" fill="url(#doraemonBlueGrad)" stroke="#005A9A" strokeWidth="0.5"/>
      {/* Head */}
      <circle cx="50" cy="48" r="40" fill="url(#doraemonBlueGrad)" stroke="#005A9A" strokeWidth="1.5"/>
      {/* Face */}
      <circle cx="50" cy="53" r="30" fill="url(#doraemonFaceGrad)" stroke="#B0B0B0" strokeWidth="0.75"/>
      
      {/* Eyes */}
      <path d={eyeShapeLeft} fill="white" stroke="black" strokeWidth="1.2"/>
      <path d={eyeShapeRight} fill="white" stroke="black" strokeWidth="1.2"/>
      <circle cx={pupilLeftX} cy={pupilY} r="3.5" fill="black"/>
      <circle cx={pupilRightX} cy={pupilY} r="3.5" fill="black"/>
      <circle cx={pupilLeftX-0.7} cy={pupilY-0.8} r="1" fill="white"/> {/* Eye highlight */}
      <circle cx={pupilRightX-0.7} cy={pupilY-0.8} r="1" fill="white"/>
      
      {/* Nose */}
      <circle cx="50" cy="56" r="6" fill="#E53935" stroke="#B71C1C" strokeWidth="0.75"/>
      <ellipse cx="48.5" cy="54.5" rx="1.5" ry="1.2" fill="white" opacity="0.9" transform="rotate(-20 48.5 54.5)"/>
      
      {/* Mouth */}
      {showRedMouthInterior && <path d={mouthPath} fill="#D32F2F" stroke="black" strokeWidth="1.2"/>}
      <path d={mouthPath} stroke="black" strokeWidth="1.2" fill={showRedMouthInterior ? 'none' : '#D32F2F'} />
      {!showRedMouthInterior && mood !== 'surprised' && <path d="M50 75 L50 79" stroke="black" strokeWidth="1" />} {/* Tongue for neutral talking */}


      {/* Whiskers */}
      <g stroke="black" strokeWidth="0.8" opacity={whiskerOpacity}>
        {[53, 60, 67].map((y, i) => <line key={`lw${y}`} x1="18" y1={y} x2="33" y2={y-(i*0.5)} strokeLinecap="round"/>)}
        {[53, 60, 67].map((y, i) => <line key={`rw${y}`} x1="82" y1={y} x2="67" y2={y-(i*0.5)} strokeLinecap="round"/>)}
      </g>
      {/* Line from nose to mouth */}
      <line x1="50" y1="62" x2="50" y2="70" stroke="black" strokeWidth="1"/>
      
      {/* Collar and Bell */}
      <path d="M28 84 Q50 90 72 84 L70 88 Q50 94 30 88 Z" fill="#D32F2F" stroke="#A02020" strokeWidth="0.75"/>
      <circle cx="50" cy="83" r="7" fill="#FFCA28" stroke="#F57F17" strokeWidth="0.75"/>
      <circle cx="50" cy="83" r="1.2" fill="#424242"/>
      <line x1="50" y1="84.2" x2="50" y2="88" stroke="#424242" strokeWidth="0.8"/>

       {/* Pocket */}
      <path d="M35 83 C35 93, 65 93, 65 83" fill="#FFFFFF" stroke="#B0B0B0" strokeWidth="0.75" />

    </svg>
  );
};

// --- Shizuka Avatar ---
const ShizukaAvatar: React.FC<{ mood?: UserMood; isTalking?: boolean; className?: string }> = ({ mood, isTalking, className="w-40 h-40" }) => {
  const skinTone = "#FFE0B2"; // Warmer fair skin
  const hairColor = "#3E2723"; // Darker brown, almost black
  const dressColor = "#F06292"; // Pink dress (shirt part)
  const collarColor = "#FFFFFF";
  const pigtailTieColor = "#FF80AB"; // Lighter pink for ties

  let eyeLeftPath = "M 38 45 A 7 8 0 1 0 38 44.9 Z"; // Default slightly oval
  let eyeRightPath = "M 62 45 A 7 8 0 1 0 62 44.9 Z";
  let pupilLX = 38, pupilLY = 45;
  let pupilRX = 62, pupilRY = 45;
  let mouthPath = "M 45 68 Q 50 71 55 68"; // Neutral gentle smile
  let blushOpacity = 0.15;
  let eyeLashAngleL = -15;
  let eyeLashAngleR = 15;

  if (mood === 'happy') {
    eyeLeftPath = "M 35 48 Q 38 42, 41 48 Z"; // Curved happy eyes
    eyeRightPath = "M 59 48 Q 62 42, 65 48 Z";
    mouthPath = "M 42 67 Q 50 73 58 67"; // Wider smile
    blushOpacity = 0.3;
  } else if (mood === 'sad') {
    eyeLeftPath = "M 35 44 Q 38 50, 41 44 Z"; // Sad, downturned eyes
    eyeRightPath = "M 59 44 Q 62 50, 65 44 Z";
    mouthPath = "M 45 71 Q 50 67 55 71"; // Frown
    pupilLY += 1; pupilRY +=1; 
    blushOpacity = 0.05;
    eyeLashAngleL = -5; eyeLashAngleR = 5;
  } else if (mood === 'surprised') {
    eyeLeftPath = "M 38 45 A 8 9 0 1 0 38 44.9 Z"; // Wide round eyes
    eyeRightPath = "M 62 45 A 8 9 0 1 0 62 44.9 Z";
    mouthPath = "M 48 67 A 3 4 0 1 0 52 67 Z"; // Small "O" mouth
    blushOpacity = 0.25;
  }

  if (isTalking) {
    const talkCycle = Date.now() % 700;
    if (talkCycle < 200) mouthPath = "M 45 68 Q 50 70 55 68"; 
    else if (talkCycle < 400) mouthPath = "M 43 67 Q 50 72 57 67"; 
    else mouthPath = "M 46 69 Q 50 67 54 69"; 
    
    // Subtle eyebrow movement when talking
    pupilLY += Math.sin(Date.now()/200)*0.2;
    pupilRX += Math.sin(Date.now()/200)*0.2;
  }

  return (
    <svg viewBox="0 0 100 100" className={className}>
       <defs><filter id="shizukaSubtleBlur"><feGaussianBlur stdDeviation="0.2"/></filter></defs>
      {/* Head */}
      <circle cx="50" cy="50" r="32" fill={skinTone} stroke="#D8A07A" strokeWidth="0.5"/>
      
      {/* Hair */}
      <g fill={hairColor} stroke={adjustColor(hairColor, -20)} strokeWidth="0.3">
        {/* Bangs */}
        <path d="M25 30 Q30 20, 50 25 Q70 20, 75 30 L70 35 Q50 28 30 35 Z" />
        <path d="M22 45 Q20 30, 35 32 C 40 45, 28 50, 22 45 Z" /> 
        <path d="M78 45 Q80 30, 65 32 C 60 45, 72 50, 78 45 Z" /> 
        {/* Main hair top */}
        <path d="M25 30 C 20 50, 80 50, 75 30 Q50 15 25 30Z" />
      </g>
      {/* Pigtails */}
      <g transform="translate(0, 5)">
        <ellipse cx="18" cy="58" rx="8" ry="17" fill={hairColor} transform="rotate(-10 18 58)"/>
        <path d="M12 60 Q18 68 24 60" stroke={adjustColor(hairColor,30)} fill="none" strokeWidth="1" transform="rotate(-10 18 58)"/>
        <ellipse cx="82" cy="58" rx="8" ry="17" fill={hairColor} transform="rotate(10 82 58)"/>
        <path d="M76 60 Q82 68 88 60" stroke={adjustColor(hairColor,30)} fill="none" strokeWidth="1" transform="rotate(10 82 58)"/>
        {/* Pigtail Ties (Bows) */}
        <g fill={pigtailTieColor} stroke={adjustColor(pigtailTieColor, -30)} strokeWidth="0.3">
            <ellipse cx="20" cy="48" rx="5" ry="3" transform="rotate(-25 20 48)"/>
            <ellipse cx="17" cy="46" rx="4" ry="2.5" transform="rotate(20 17 46)"/>
            <ellipse cx="80" cy="48" rx="5" ry="3" transform="rotate(25 80 48)"/>
            <ellipse cx="83" cy="46" rx="4" ry="2.5" transform="rotate(-20 83 46)"/>
        </g>
      </g>

      {/* Eyes */}
      <path d={eyeLeftPath} fill="white" stroke="black" strokeWidth="0.8"/>
      <path d={eyeRightPath} fill="white" stroke="black" strokeWidth="0.8"/>
      { mood !== 'happy' && <>
          <circle cx={pupilLX} cy={pupilLY} r="3" fill="black"/>
          <circle cx={pupilRX} cy={pupilRY} r="3" fill="black"/>
          <circle cx={pupilLX-0.6} cy={pupilLY-0.7} r="1.1" fill="white"/> {/* Eye highlight */}
          <circle cx={pupilRX-0.6} cy={pupilRY-0.7} r="1.1" fill="white"/>
        </>
      }
      {/* Eyelashes (more defined for Shizuka) */}
      { mood !== 'happy' && 
        <>
          <path d={`M${pupilLX-3.5} ${pupilLY-3} Q${pupilLX-4.5} ${pupilLY-5} ${pupilLX-5.5} ${pupilLY-7}`} stroke="black" strokeWidth="0.6" fill="none" transform={`rotate(${eyeLashAngleL} ${pupilLX} ${pupilLY})`}/>
          <path d={`M${pupilLX-1.5} ${pupilLY-3.5} Q${pupilLX-2} ${pupilLY-5.5} ${pupilLX-2.5} ${pupilLY-7.5}`} stroke="black" strokeWidth="0.6" fill="none" transform={`rotate(${eyeLashAngleL} ${pupilLX} ${pupilLY})`}/>
          <path d={`M${pupilRX+3.5} ${pupilRY-3} Q${pupilRX+4.5} ${pupilRY-5} ${pupilRX+5.5} ${pupilRY-7}`} stroke="black" strokeWidth="0.6" fill="none" transform={`rotate(${eyeLashAngleR} ${pupilRX} ${pupilRY})`}/>
          <path d={`M${pupilRX+1.5} ${pupilRY-3.5} Q${pupilRX+2} ${pupilRY-5.5} ${pupilRX+2.5} ${pupilRY-7.5}`} stroke="black" strokeWidth="0.6" fill="none" transform={`rotate(${eyeLashAngleR} ${pupilRX} ${pupilRY})`}/>
        </>
      }

      {/* Nose (very subtle) */}
      <path d="M49 58 L50 60 L51 58" fill="none" stroke="#C6A080" strokeWidth="0.5" strokeLinecap="round"/>
      
      {/* Blush */}
      <ellipse cx="38" cy="57" rx="6" ry="3.5" fill="#FFAB91" opacity={blushOpacity} filter="url(#shizukaSubtleBlur)"/>
      <ellipse cx="62" cy="57" rx="6" ry="3.5" fill="#FFAB91" opacity={blushOpacity} filter="url(#shizukaSubtleBlur)"/>
      
      {/* Mouth */}
      <path d={mouthPath} stroke="#B7524F" strokeWidth="0.8" fill="none" strokeLinecap="round"/>
      
      {/* Dress (Shirt and Collar) */}
      <path d="M35 78 Q50 88 65 78 L60 95 H40 Z" fill={dressColor} stroke={adjustColor(dressColor, -40)} strokeWidth="0.5"/>
      <path d="M40 78 Q38 82 45 83 L50 80 L40 78 M60 78 Q62 82 55 83 L50 80 L60 78" fill={collarColor} stroke="#BDBDBD" strokeWidth="0.3"/>
    </svg>
  );
};


// Persona feature definitions for Alex and Riley
const alexPersonaFeatures: VirtualCharacterHumanoidProps['personaFeatures'] = {
  eyeShapePreset: 'almond', noseShapePreset: 'straight', lipShapePreset: 'medium',
  faceShapePath: "M28 28 C15 35, 10 60, 28 88 Q50 102 72 88 C90 60, 85 35, 72 28 Q50 8 28 28 Z", // Slightly leaner jaw
  earShapePath: "M23 48 C18 52, 18 63, 23 67 Q27 72 30 63 C30 54 27 49 23 48 Z", // Standard ear
  hairStylePaths: {
    main: "M25 22 C18 12, 82 12, 75 22 L80 65 Q50 78 20 65 Z", // Shorter, layered
    highlights: ["M30 28 Q50 18 70 28", "M35 33 Q50 25 65 33"],
    shadows: ["M30 55 Q50 60 70 55"],
    flyaways: "M26 20 q-2 -6 3 -8 M74 20 q2 -6 -3 -8",
    roots: "M28 23 C22 18, 78 18, 72 23 C70 28, 30 28, 28 23Z",
    strandDetails: ["M40 25 q5 -7 10 -1", "M60 26 q-5 -6 -8 0"],
  }
};

const rileyPersonaFeatures: VirtualCharacterHumanoidProps['personaFeatures'] = {
  eyeShapePreset: 'round', noseShapePreset: 'button', lipShapePreset: 'full',
  faceShapePath: "M25 30 C12 40, 8 70, 30 90 Q50 105 70 90 C92 70, 88 40, 75 30 Q50 12 25 30 Z", // Softer, rounder face
  earShapePath: "M24 49 C19 53, 19 64, 24 68 Q28 73 31 64 C31 55 28 50 24 49 Z", // Slightly rounder ear
  hairStylePaths: {
    main: "M18 28 C5 35, 5 75, 25 85 Q50 98 75 85 C95 75, 95 35, 82 28 Q50 5 18 28", // Longer, wavier
    highlights: ["M22 33 Q50 20 78 33", "M28 38 Q50 28 72 38"],
    shadows: ["M25 75 Q50 82 75 75"],
    flyaways: "M20 25 q-3 -5 2 -7 M80 25 q3 -5 -2 -7",
    roots: "M22 29 C15 24, 85 24, 78 29 C75 34, 25 34, 22 29Z",
    strandDetails: ["M30 40 q10 -10 15 2", "M70 42 q-10 -12 -13 0", "M50 30 q0 -8 5 -10"],
  }
};

// --- Placeholders for Alex and Riley using the Hyper-Realistic Character ---
const AlexAvatarPlaceholder: React.FC<{ isTalking: boolean; userMood: UserMood }> = ({ isTalking, userMood }) => {
  const colors = useMemo(() => ({
    skinBase: "#D8C0A8", skinShadowLight: adjustColor("#D8C0A8", -10), skinShadowMedium: adjustColor("#D8C0A8", -22), skinShadowDeep: adjustColor("#D8C0A8", -35), skinHighlight: adjustColor("#D8C0A8", 15), skinPoreColor: adjustColor("#D8C0A8", -6), skinUndertone: "#E0B0A0", skinBlushColor: "#D8A088",
    lipBase: "#C8A090", lipHighlight: adjustColor("#C8A090", 10), lipVermillionBorder: adjustColor("#C8A090", -8), lipInnerEdge: adjustColor("#C8A090", -12), lipGlossHighlight: adjustColor("#C8A090", 20),
    hairBase: "#5A4A3A", hairHighlightPrimary: adjustColor("#5A4A3A", 30), hairHighlightSecondary: adjustColor("#5A4A3A", 50), hairShadowPrimary: adjustColor("#5A4A3A", -20), hairShadowSecondary: adjustColor("#5A4A3A", -35), hairFlyawayColor: adjustColor("#5A4A3A", 15), hairRootColor: adjustColor("#5A4A3A", -10), hairShadowDeep: adjustColor("#5A4A3A", -50),
    irisBase: "#60A0C0", irisAccent1: adjustColor("#60A0C0", 20), irisAccent2: adjustColor("#60A0C0", -12), irisLimbalRing: adjustColor("#60A0C0", -30), irisHighlightColor: "#FFFFFF", irisShadow: adjustColor("#60A0C0", -45), irisPatternColor: adjustColor("#60A0C0", 10),
    scleraBase: "#F6F6F6", scleraVeinColor: "#FFD0D0", scleraShadow: "#D8D8E0", scleraHighlight: "#FFFFFF",
    lashLineColor: "#38281C", eyebrowColor: "#605040", eyebrowStrokeColor: adjustColor("#605040", 10),
    innerMouthColor: "#A85868", tongueColor: "#C87888", teethBaseColor: "#F2F2EA", teethHighlightColor: "#FFFFFF", gumColor: "#DC98A8",
    clothingBaseColor: "#4A708B", clothingHighlightColor: adjustColor("#4A708B", 18), clothingShadowColor: adjustColor("#4A708B", -28), clothingTextureColor: adjustColor("#4A708B", 8), clothingAccentColor: "#A0B0C0",
  }), []);
  return (
    <div className={`p-1 rounded-lg transition-all duration-300 ease-in-out flex flex-col items-center justify-center ${isTalking ? 'avatar-human-talking avatar-talking-glow' : ''} bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900 shadow-2xl relative`} style={{ width: '220px', height: '270px' }}>
      <VirtualCharacterHumanoid key={`alex-hyperreal-${userMood || 'initial'}`} className="w-full h-full" mood={userMood} isTalking={isTalking} personaFeatures={alexPersonaFeatures} {...colors} />
      <p className="absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-black bg-opacity-70 rounded text-sm font-medium text-blue-300 shadow">Alex</p>
    </div>
  );
};

const RileyAvatarPlaceholder: React.FC<{ isTalking: boolean; userMood: UserMood }> = ({ isTalking, userMood }) => {
   const colors = useMemo(() => ({
    skinBase: "#F2D8C8", skinShadowLight: adjustColor("#F2D8C8", -10), skinShadowMedium: adjustColor("#F2D8C8", -22), skinShadowDeep: adjustColor("#F2D8C8", -35), skinHighlight: adjustColor("#F2D8C8", 15), skinPoreColor: adjustColor("#F2D8C8", -6), skinUndertone: "#F0C0B0", skinBlushColor: "#E8B0A0",
    lipBase: "#E0A8B8", lipHighlight: adjustColor("#E0A8B8", 10), lipVermillionBorder: adjustColor("#E0A8B8", -8), lipInnerEdge: adjustColor("#E0A8B8", -12), lipGlossHighlight: adjustColor("#E0A8B8", 20),
    hairBase: "#D070E0", hairHighlightPrimary: adjustColor("#D070E0", 30), hairHighlightSecondary: adjustColor("#D070E0", 50), hairShadowPrimary: adjustColor("#D070E0", -20), hairShadowSecondary: adjustColor("#D070E0", -35), hairFlyawayColor: adjustColor("#D070E0", 15), hairRootColor: adjustColor("#D070E0", -10), hairShadowDeep: adjustColor("#D070E0", -50),
    irisBase: "#B878D8", irisAccent1: adjustColor("#B878D8", 20), irisAccent2: adjustColor("#B878D8", -12), irisLimbalRing: adjustColor("#B878D8", -30), irisHighlightColor: "#FFFFFF", irisShadow: adjustColor("#B878D8", -45), irisPatternColor: adjustColor("#B878D8", 10),
    scleraBase: "#F7F7F7", scleraVeinColor: "#FFD8D8", scleraShadow: "#E0E0E8", scleraHighlight: "#FFFFFF",
    lashLineColor: "#583868", eyebrowColor: "#785888", eyebrowStrokeColor: adjustColor("#785888",10),
    innerMouthColor: "#B86878", tongueColor: "#D88898", teethBaseColor: "#F4F4EC", teethHighlightColor: "#FFFFFF", gumColor: "#E8A8B8",
    clothingBaseColor: "#D050E0", clothingHighlightColor: adjustColor("#D050E0", 18), clothingShadowColor: adjustColor("#D050E0", -28), clothingTextureColor: adjustColor("#D050E0", 8), clothingAccentColor: "#E0A0F0",
  }), []);
  return (
    <div className={`p-1 rounded-lg transition-all duration-300 ease-in-out flex flex-col items-center justify-center ${isTalking ? 'avatar-human-talking avatar-talking-glow' : ''} bg-gradient-to-br from-purple-700 via-purple-800 to-fuchsia-900 shadow-2xl relative`} style={{ width: '220px', height: '270px' }}>
      <VirtualCharacterHumanoid key={`riley-hyperreal-${userMood || 'initial'}`} className="w-full h-full" mood={userMood} isTalking={isTalking} personaFeatures={rileyPersonaFeatures} {...colors} />
      <p className="absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-black bg-opacity-70 rounded text-sm font-medium text-purple-300 shadow">Riley</p>
    </div>
  );
};


// Main AvatarDisplay component
const AvatarDisplay: React.FC<AvatarDisplayProps> = ({ isTalking, avatarStyle, userMood }) => {
  let AvatarComponentToRender;

  switch (avatarStyle) {
    case 'alex':
      AvatarComponentToRender = <AlexAvatarPlaceholder isTalking={isTalking} userMood={userMood} />;
      break;
    case 'riley':
      AvatarComponentToRender = <RileyAvatarPlaceholder isTalking={isTalking} userMood={userMood} />;
      break;
    case 'doraemon':
      AvatarComponentToRender = <DoraemonAvatar className="w-48 h-48 md:w-56 md:h-56 lg:w-64 lg:h-64" mood={userMood} isTalking={isTalking} />;
      break;
    case 'shizuka':
      AvatarComponentToRender = <ShizukaAvatar className="w-48 h-48 md:w-56 md:h-56 lg:w-64 lg:h-64" mood={userMood} isTalking={isTalking} />;
      break;
    default: // Fallback to Riley or a default human
      AvatarComponentToRender = <RileyAvatarPlaceholder isTalking={isTalking} userMood={userMood} />;
  }
  
  return (
    <div className="avatar-container w-full h-full flex justify-center items-center p-2 md:p-4">
      {AvatarComponentToRender}
    </div>
  );
};

export default AvatarDisplay;
