
import React, { useRef, useEffect, useMemo } from 'react';
import ChatWindow from './components/ChatWindow';
import AvatarDisplay from './components/AvatarDisplay';
import { useAivaChat } from './hooks/useAivaChat'; 
import { isApiKeyMissing as checkIsApiKeyMissing } from './services/geminiService';
import { CameraPermissionStatus, AvatarStyle, SUPPORTED_LANGUAGES, LanguageOption } from './types';

const App: React.FC = () => {
  const isApiKeyMissing = checkIsApiKeyMissing;
  const videoFeedRef = useRef<HTMLVideoElement | null>(null);

  const {
    messages, sendMessage, isLoading, error: apiError, clearChat,
    isRecording, startRecording, stopRecording, sttError, setSttError, sttTranscript, setSttTranscript, isSttSupported,
    playMessageAudio, cancelTts, isTtsSupported, isAivaSpeaking,      
    currentAvatarStyle, changeAvatarStyle, // Updated from toggleAvatarStyle
    availableVoices, selectedVoiceURI, changeVoice,
    selectedLanguageCode, changeLanguage, availableLanguages,
    userMood, cameraPermissionStatus, isMoodDetectionActive, toggleMoodDetection,      
  } = useAivaChat();

  const avatarOptions: { value: AvatarStyle; label: string }[] = [
    { value: 'riley', label: 'Riley (Human)' },
    { value: 'alex', label: 'Alex (Human)' },
    { value: 'doraemon', label: 'Doraemon (Cartoon)' },
    { value: 'shizuka', label: 'Shizuka (Cartoon)' },
  ];

  const isHumanAvatarSelected = currentAvatarStyle === 'alex' || currentAvatarStyle === 'riley';

  useEffect(() => {
    // If a non-human avatar is selected and mood detection is active, turn it off.
    if (!isHumanAvatarSelected && isMoodDetectionActive) {
      toggleMoodDetection(videoFeedRef.current);
    }
  }, [currentAvatarStyle, isMoodDetectionActive, toggleMoodDetection]);


  if (isApiKeyMissing) {
    return (
      <div className="flex items-center justify-center h-screen bg-red-900 text-white p-4">
        <div className="text-center p-8 bg-gray-800 shadow-xl rounded-lg max-w-md w-full">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-red-400 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <h1 className="text-3xl font-bold mb-3 text-red-300">Configuration Error</h1>
          <p className="text-gray-300 text-lg">The Gemini API Key is not configured.</p>
          <p className="mt-2 text-sm text-gray-400">Please ensure the <code>API_KEY</code> environment variable is set for AIVA to function.</p>
        </div>
      </div>
    );
  }
  
  const chatWindowProps = {
    messages, sendMessage, isLoading, error: apiError, clearChat,
    isRecording, startRecording, stopRecording, sttError, setSttError, sttTranscript, setSttTranscript, isSttSupported,
    playMessageAudio, isTtsSupported,
  };

  const renderMoodDetectionButtonIcon = () => { /* ... (same as before) ... */ 
    if (cameraPermissionStatus === 'pending') {
      return ( 
        <svg className="h-5 w-5 sm:h-6 sm:w-6 text-yellow-300 animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      );
    }
    if (isMoodDetectionActive) {
      return ( 
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6 text-green-300" viewBox="0 0 20 20" fill="currentColor">
          <path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zm14.553 1.106A1 1 0 0016 8.447V11.553a1 1 0 001.553.841l2-1.553A1 1 0 0019.5 9.5V8.5a1 1 0 00-.947-.841l-2-1.553z" />
        </svg>
      );
    }
    return ( 
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6 text-red-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M10 15a2 2 0 100-4 2 2 0 000 4zm0 0h8m-8 0a2 2 0 110-4H2a2 2 0 100 4h8zm0 0a2 2 0 010-4h4a2 2 0 110 4h-4zM3 10h.01M7 10h.01M11 10h.01"/>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
      </svg>
    );
  };
  
  const getCameraStatusMessage = (status: CameraPermissionStatus): string | null => { /* ... (same as before) ... */ 
    if (status === 'pending') return "Requesting camera access...";
    if (status === 'denied' && !isMoodDetectionActive) return "Camera access denied. Enable in browser settings.";
    if (isMoodDetectionActive && status === 'granted') return "Mood detection active.";
    return null;
  };

  const filteredVoices = useMemo(() => {
    if (!selectedLanguageCode || !availableVoices) return [];
    const targetLang = selectedLanguageCode.toLowerCase();
    const targetLangShort = targetLang.split('-')[0];
    return availableVoices.filter(v => v.lang.toLowerCase().startsWith(targetLang) || v.lang.toLowerCase().startsWith(targetLangShort));
  }, [selectedLanguageCode, availableVoices]);


  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-gray-900 via-purple-950 to-slate-900 text-white selection:bg-purple-600 selection:text-white">
      <header className="bg-black bg-opacity-50 backdrop-blur-md p-3 md:p-4 shadow-lg border-b border-gray-700 sticky top-0 z-20 flex items-center justify-between flex-wrap gap-2 md:gap-4">
        
        <div className="flex items-center space-x-2 md:space-x-3">
          {isTtsSupported && (
            <>
              <div className="flex items-center space-x-1">
                <label htmlFor="lang-select" className="text-xs sm:text-sm text-gray-300 hidden sm:inline">Lang:</label>
                <select
                  id="lang-select"
                  value={selectedLanguageCode}
                  onChange={(e) => changeLanguage(e.target.value)}
                  className="bg-gray-700 text-white text-xs sm:text-sm rounded-md p-1.5 sm:p-2 border border-gray-600 focus:ring-1 focus:ring-purple-500 focus:border-purple-500 hover:bg-gray-600 transition-colors max-w-[100px] sm:max-w-[120px]"
                  aria-label="Select Language" title="Select Language"
                >
                  {availableLanguages.map(lang => (
                    <option key={lang.code} value={lang.code} title={lang.name}>
                      {lang.code.split('-')[0].toUpperCase()}
                    </option>
                  ))}
                </select>
              </div>
              {filteredVoices.length > 0 && (
                <div className="flex items-center space-x-1">
                  <label htmlFor="voice-select" className="text-xs sm:text-sm text-gray-300 hidden sm:inline">Voice:</label>
                  <select
                    id="voice-select"
                    value={selectedVoiceURI || ''}
                    onChange={(e) => changeVoice(e.target.value || null)}
                    className="bg-gray-700 text-white text-xs sm:text-sm rounded-md p-1.5 sm:p-2 border border-gray-600 focus:ring-1 focus:ring-purple-500 focus:border-purple-500 hover:bg-gray-600 transition-colors max-w-[100px] sm:max-w-[160px] truncate"
                    aria-label="Select AIVA's voice" title="Select AIVA's voice"
                  >
                    <option value="">Auto (Lang Default)</option>
                    {filteredVoices.map(voice => (
                      <option key={voice.voiceURI} value={voice.voiceURI} title={`${voice.name} (${voice.lang})`}>
                        {voice.name.length > 18 ? `${voice.name.substring(0,15)}...` : voice.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </>
          )}
        </div>

        <div className="flex-shrink-0 text-center px-2 order-first md:order-none w-full md:w-auto mb-2 md:mb-0">
          <h1 className="text-2xl sm:text-3xl font-bold">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-orange-400">AIVA</span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400 hidden sm:block">Autonomous Interactive Virtual Assistant</p>
        </div>

        <div className="flex items-center space-x-2 md:space-x-3">
            <div className="flex items-center space-x-1">
                <label htmlFor="avatar-select" className="text-xs sm:text-sm text-gray-300 hidden sm:inline">Avatar:</label>
                <select
                    id="avatar-select"
                    value={currentAvatarStyle}
                    onChange={(e) => changeAvatarStyle(e.target.value as AvatarStyle)}
                    className="bg-gray-700 text-white text-xs sm:text-sm rounded-md p-1.5 sm:p-2 border border-gray-600 focus:ring-1 focus:ring-purple-500 focus:border-purple-500 hover:bg-gray-600 transition-colors max-w-[120px] sm:max-w-[180px] truncate"
                    aria-label="Select Avatar Persona" title="Select Avatar Persona"
                >
                    {avatarOptions.map(opt => (
                        <option key={opt.value} value={opt.value} title={opt.label}>
                            {opt.label.length > 20 ? `${opt.label.substring(0,17)}...` : opt.label}
                        </option>
                    ))}
                </select>
            </div>
          {isHumanAvatarSelected && (
            <button
                onClick={() => toggleMoodDetection(videoFeedRef.current)}
                title={isMoodDetectionActive ? "Disable Mood Detection" : "Enable Mood Detection"}
                className="p-2 rounded-full hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors"
                aria-label="Toggle Mood Detection"
            >
                {renderMoodDetectionButtonIcon()}
            </button>
          )}
        </div>
      </header>
      
      <div className="bg-black bg-opacity-20 backdrop-blur-sm p-3 md:p-4 flex flex-col justify-center items-center shadow-inner min-h-[250px] md:min-h-[300px] lg:min-h-[350px] relative z-10">
        <AvatarDisplay 
          isTalking={isAivaSpeaking} 
          avatarStyle={currentAvatarStyle} 
          userMood={userMood}
        />
        {isHumanAvatarSelected && (
            <div className="absolute bottom-2 left-2 right-2 text-center">
                <video 
                  ref={videoFeedRef} 
                  id="video-feed" 
                  className={`w-32 h-24 sm:w-40 sm:h-30 md:w-48 md:h-36 mx-auto border border-purple-700 rounded-md shadow-lg ${
                    isMoodDetectionActive && cameraPermissionStatus === 'granted' ? 'block' : 'hidden'
                  }`} 
                  autoPlay 
                  playsInline 
                  muted
                ></video>
                {getCameraStatusMessage(cameraPermissionStatus) && (
                     <p className={`text-xs mt-1 px-2 py-1 rounded ${cameraPermissionStatus === 'denied' && !isMoodDetectionActive ? 'bg-red-800 bg-opacity-70 text-red-200' : 'bg-black bg-opacity-50 text-gray-300'}`}>
                        {getCameraStatusMessage(cameraPermissionStatus)}
                     </p>
                )}
            </div>
        )}
      </div>

      <div className="flex-1 flex flex-col overflow-hidden">
        <ChatWindow {...chatWindowProps} />
      </div>

      <footer className="p-3 bg-black bg-opacity-50 backdrop-blur-md text-center text-xs text-gray-500 border-t border-gray-700 sticky bottom-0 z-20">
        AIVA - Phase 4 (Cartoon Avatars & Multi-Language Voices) | Powered by Gemini
      </footer>
    </div>
  );
};

export default App;
