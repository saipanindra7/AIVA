
export enum MessageSender {
  USER = 'user',
  AIVA = 'aiva',
  SYSTEM = 'system', 
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: MessageSender;
  timestamp: Date;
  sources?: GroundingSource[];
}

// Updated AvatarStyle to include human-like personas and cartoon characters
export type AvatarStyle = 'alex' | 'riley' | 'doraemon' | 'shizuka';

// Types for Mood Detection
export type UserMood = 'neutral' | 'happy' | 'sad' | 'surprised' | null;
export type CameraPermissionStatus = 'idle' | 'pending' | 'granted' | 'denied';

// Types for Language Selection
export interface LanguageOption {
  code: string; // e.g., 'en-us', 'ja-jp' (BCP 47, typically lowercase)
  name: string; // e.g., 'English (US)', '日本語 (日本)'
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'en-us', name: 'English (US)' },
  { code: 'en-gb', name: 'English (UK)' },
  { code: 'ja-jp', name: '日本語 (Japan)' },
  { code: 'hi-in', name: 'हिन्दी (India)' },
  { code: 'es-es', name: 'Español (España)' },
  { code: 'fr-fr', name: 'Français (France)' },
];