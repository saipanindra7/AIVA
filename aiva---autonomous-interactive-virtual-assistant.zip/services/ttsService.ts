
// services/ttsService.ts

export const isTtsSupported = (): boolean => !!window.speechSynthesis;

let currentUtterance: SpeechSynthesisUtterance | null = null;

export const speak = (
  text: string, 
  onStart?: () => void,
  onEnd?: () => void, 
  onError?: (error: string) => void,
  voiceURI?: string, // Voice URI for specific voice selection
  lang?: string // Optional BCP 47 language code for the utterance
): void => {
  if (!isTtsSupported()) {
    if (onError) onError("Text-to-speech is not supported in this browser.");
    console.warn("TTS not supported");
    return;
  }

  cancel(); 

  currentUtterance = new SpeechSynthesisUtterance(text);
  const normalizedRequestLang = lang?.toLowerCase();

  if (normalizedRequestLang) {
    currentUtterance.lang = normalizedRequestLang;
    console.log(`TTS Service: Utterance language set to ${normalizedRequestLang}`);
  }

  if (voiceURI) {
    const voices = speechSynthesis.getVoices();
    const selectedVoice = voices.find(v => v.voiceURI === voiceURI);
    if (selectedVoice) {
      currentUtterance.voice = selectedVoice;
      const normalizedVoiceLang = selectedVoice.lang.toLowerCase();
      if (normalizedRequestLang && normalizedVoiceLang !== normalizedRequestLang) {
          console.warn(`TTS Service: Selected voice "${selectedVoice.name}" has lang "${selectedVoice.lang}" which differs from requested "${lang}". Utterance lang remains "${normalizedRequestLang}".`);
      }
       console.log(`TTS Service: Using voice "${selectedVoice.name}" (${selectedVoice.lang})`);
    } else {
      console.warn(`TTS Service: Voice URI "${voiceURI}" not found. Using language default or browser default voice.`);
    }
  } else if (normalizedRequestLang) {
     const voices = speechSynthesis.getVoices();
     const langDefaultVoice = voices.find(v => v.lang.toLowerCase() === normalizedRequestLang && v.default) || voices.find(v => v.lang.toLowerCase() === normalizedRequestLang);
     if (langDefaultVoice) {
         currentUtterance.voice = langDefaultVoice;
         console.log(`TTS Service: Using default voice "${langDefaultVoice.name}" for language "${normalizedRequestLang}"`);
     } else {
         console.warn(`TTS Service: No default voice found for language "${normalizedRequestLang}". Browser will attempt to use a fallback.`);
     }
  }


  currentUtterance.onstart = () => {
    if (onStart) onStart();
  };

  currentUtterance.onend = () => {
    currentUtterance = null;
    if (onEnd) onEnd();
  };

  currentUtterance.onerror = (event: SpeechSynthesisErrorEvent) => {
    console.warn(`SpeechSynthesis Internal Error Code: ${event.error}`);
    
    if (event.error === 'interrupted' || event.error === 'canceled') {
      console.log(`TTS Info: Speech utterance was ${event.error}.`);
      currentUtterance = null; 
      // onEnd should still fire and handle hook's onEnd callback.
      return; 
    }

    currentUtterance = null; 
    if (onError) {
        let errorMessage = `TTS Error: ${event.error}`;
        if ((event.error as string) === 'audio-unavailable') { 
            errorMessage = "TTS playback failed (audio-unavailable). Check audio output or browser interaction.";
        } else if (event.error === 'voice-unavailable') {
             errorMessage = "TTS Error: The selected voice is unavailable or could not be loaded.";
        } else if (event.error === 'language-unavailable') {
             errorMessage = `TTS Error: The language "${currentUtterance?.lang || lang}" is not supported by available voices.`;
        } else if (event.error === 'text-too-long') {
             errorMessage = "TTS Error: The text to speak is too long for the speech engine.";
        }
        onError(errorMessage);
    }
  };
  
  try {
    speechSynthesis.speak(currentUtterance);
  } catch (e: any) {
    console.error("Error calling speechSynthesis.speak:", e);
    if (onError) onError(`Failed to initiate TTS: ${e.message}`);
    currentUtterance = null; 
  }
};

export const cancel = (): void => {
  if (isTtsSupported() && (speechSynthesis.speaking || speechSynthesis.pending)) {
    speechSynthesis.cancel();
  }
};

export const getVoices = (): SpeechSynthesisVoice[] => {
  if (!isTtsSupported()) return [];
  return speechSynthesis.getVoices();
};