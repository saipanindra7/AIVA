// services/moodDetectionService.ts
import { UserMood, CameraPermissionStatus } from '../types';

let moodUpdateInterval: number | null = null;
let currentStream: MediaStream | null = null;
const availableMoods: UserMood[] = ['happy', 'sad', 'surprised', 'neutral'];
let currentMoodIndex = 0;

export const requestCameraPermission = async (): Promise<{ status: CameraPermissionStatus; stream: MediaStream | null }> => {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return { status: 'denied', stream: null }; // Browser doesn't support getUserMedia
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    currentStream = stream;
    return { status: 'granted', stream };
  } catch (err) {
    console.error("Error requesting camera permission:", err);
    if ((err as Error).name === 'NotAllowedError' || (err as Error).name === 'PermissionDeniedError') {
      return { status: 'denied', stream: null };
    }
    return { status: 'denied', stream: null };
  }
};

export const startVideo = (
  videoElement: HTMLVideoElement,
  onMoodUpdate: (mood: UserMood) => void,
  stream: MediaStream
): void => {
  if (!videoElement || !stream) return;

  videoElement.srcObject = stream;
  videoElement.play().catch(err => console.error("Error playing video stream:", err));

  // Simulate mood detection by cycling through moods
  if (moodUpdateInterval) clearInterval(moodUpdateInterval);
  currentMoodIndex = 0; // Reset index when starting
  
  // Set initial mood immediately
  const initialMood = availableMoods[currentMoodIndex];
  onMoodUpdate(initialMood);
  console.log("Mood Service: Initial mood set to", initialMood);


  moodUpdateInterval = window.setInterval(() => {
    currentMoodIndex = (currentMoodIndex + 1) % availableMoods.length;
    const newMood: UserMood = availableMoods[currentMoodIndex];
    onMoodUpdate(newMood);
    console.log("Mood Service: Updated mood to", newMood);
  }, 3000); // Update mood every 3 seconds
};

export const stopVideo = (videoElement: HTMLVideoElement | null): MediaStream | null => {
  if (moodUpdateInterval) {
    clearInterval(moodUpdateInterval);
    moodUpdateInterval = null;
  }
  currentMoodIndex = 0; // Reset index
  
  const streamToStop = currentStream;

  if (streamToStop) {
    streamToStop.getTracks().forEach(track => track.stop());
  }

  if (videoElement && videoElement.srcObject) {
    videoElement.pause();
    videoElement.srcObject = null;
  }
  currentStream = null;
  // It's good practice to also call onMoodUpdate to reset to a default state if desired
  // For example: onMoodUpdate('neutral'); // This would require onMoodUpdate to be available or passed differently.
  // However, useAivaChat already resets userMood to 'neutral' when toggling off.
  return streamToStop; 
};