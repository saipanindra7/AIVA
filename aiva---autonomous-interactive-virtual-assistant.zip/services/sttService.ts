
// services/sttService.ts

// Manually define TypeScript interfaces for the Web Speech API
// This helps ensure TypeScript recognizes these types, especially if not available in the default lib.
interface SpeechRecognitionErrorEvent extends Event {
  readonly error: string;
  readonly message: string;
}

interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
  readonly interpretation?: any;
  readonly emma?: Document;
}

interface SpeechRecognitionResult {
  readonly isFinal: boolean;
  readonly [index: number]: SpeechRecognitionAlternative;
  readonly length: number;
}

interface SpeechRecognitionAlternative {
  readonly transcript: string;
  readonly confidence: number;
}

interface SpeechRecognitionResultList {
  readonly length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechGrammar {
  src: string;
  weight?: number;
}

interface SpeechGrammarList {
  readonly length: number;
  item(index: number): SpeechGrammar;
  [index: number]: SpeechGrammar;
  addFromString(string: string, weight?: number): void;
  addFromURI(src: string, weight?: number): void;
}

interface SpeechRecognition extends EventTarget {
  grammars: SpeechGrammarList;
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  serviceURI?: string;

  onaudiostart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onsoundstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onspeechstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onspeechend: ((this: SpeechRecognition, ev: Event) => any) | null;
  onsoundend: ((this: SpeechRecognition, ev: Event) => any) | null;
  onaudioend: ((this: SpeechRecognition, ev: Event) => any) | null;
  onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onnomatch: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
  onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null;
  onstart: ((this: SpeechRecognition, ev: Event) => any) | null;
  onend: ((this: SpeechRecognition, ev: Event) => any) | null;

  abort(): void;
  start(): void;
  stop(): void;
}

interface SpeechRecognitionStatic {
  new(): SpeechRecognition;
}

// Augment the Window interface to include SpeechRecognition and webkitSpeechRecognition
declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionStatic;
    webkitSpeechRecognition?: SpeechRecognitionStatic;
  }
}; 

interface STTServiceOptions {
  onResult: (transcript: string, isFinal: boolean) => void;
  onError: (error: string) => void;
  onEnd?: () => void;
  onStart?: () => void;
  lang?: string; // Optional language parameter
}

const SpeechRecognitionAPIConstructor = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognitionInstance: SpeechRecognition | null = null;

export const isSttSupported = (): boolean => !!SpeechRecognitionAPIConstructor;

export const startListening = (options: STTServiceOptions): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (!isSttSupported() || !SpeechRecognitionAPIConstructor) {
      options.onError("Speech recognition is not supported in this browser.");
      reject("Speech recognition not supported");
      return;
    }

    if (recognitionInstance) {
      console.log("STT: Existing instance found, stopping it first.");
      recognitionInstance.onend = null; 
      recognitionInstance.onerror = null; 
      recognitionInstance.onstart = null;
      recognitionInstance.onresult = null;
      recognitionInstance.onaudiostart = null;
      recognitionInstance.onsoundstart = null;
      recognitionInstance.onspeechstart = null;
      recognitionInstance.onspeechend = null;
      recognitionInstance.onsoundend = null;
      recognitionInstance.onaudioend = null;

      try {
        recognitionInstance.stop();
      } catch (e) {
        console.warn("STT: Error stopping previous instance:", e);
      }
      recognitionInstance = null; 
    }

    console.log("STT: Creating new SpeechRecognition instance.");
    recognitionInstance = new SpeechRecognitionAPIConstructor();
    recognitionInstance.continuous = false; 
    recognitionInstance.interimResults = true;
    recognitionInstance.lang = options.lang || 'en-US'; // Use provided lang or default
    console.log(`STT: Language set to ${recognitionInstance.lang}`);


    recognitionInstance.onaudiostart = () => console.log("STT Event: audiostart");
    recognitionInstance.onsoundstart = () => console.log("STT Event: soundstart");
    recognitionInstance.onspeechstart = () => console.log("STT Event: speechstart");
    recognitionInstance.onspeechend = () => console.log("STT Event: speechend");
    recognitionInstance.onsoundend = () => console.log("STT Event: soundend");
    recognitionInstance.onaudioend = () => console.log("STT Event: audioend");

    recognitionInstance.onstart = () => {
      console.log("STT Event: start");
      if (options.onStart) options.onStart();
      resolve();
    };

    recognitionInstance.onresult = (event: SpeechRecognitionEvent) => {
      let interimTranscript = '';
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      if (finalTranscript) {
        options.onResult(finalTranscript, true);
      } else if (interimTranscript) {
        options.onResult(interimTranscript, false);
      }
    };

    recognitionInstance.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error("STT Event: error - Code:", event.error, "Message:", event.message);
      let errorMessage = event.error;
      // User-friendly error messages (same as before)
      if (event.error === 'no-speech') {
        errorMessage = "No speech detected. Please ensure your microphone is active, unmuted, has adequate volume, and try speaking clearly. Click the mic icon to try again.";
      } else if (event.error === 'audio-capture') {
        errorMessage = "Audio capture failed. Check microphone connection, OS/browser permissions, and ensure it's not in use by another app.";
      } else if (event.error === 'not-allowed') {
        errorMessage = "Microphone access denied. Please enable it in your browser's site settings and refresh the page.";
      } else if (event.error === 'network') {
          errorMessage = "Network error during speech recognition. Please check your internet connection.";
      } else if (event.error === 'aborted') {
          errorMessage = "Speech recognition aborted. If this was unexpected, please try again.";
      } else if (event.error === 'bad-grammar') {
          errorMessage = "Speech recognition error: Bad grammar specification.";
      } else if (event.error === 'language-not-supported') {
          errorMessage = `Speech recognition error: Language (${recognitionInstance?.lang}) not supported. Please select another language.`;
      } else if (event.error === 'service-not-allowed') {
           errorMessage = "Speech recognition service not allowed by user agent or user. Check browser policies and permissions.";
      } else {
        errorMessage = `Speech recognition error: ${event.error}. ${event.message || 'Details unavailable.'}`;
      }
      options.onError(errorMessage);
      
      if (recognitionInstance && (event.error === 'no-speech' || event.error === 'audio-capture' || event.error === 'network')) {
        try {
          recognitionInstance.abort();
        } catch (e) {
          console.warn(`STT: Error calling abort() in onerror handler: ${e}`);
        }
      }
    };

    recognitionInstance.onend = () => {
      console.log("STT Event: end - Recognition service has ended.");
      if (options.onEnd) options.onEnd(); 
      recognitionInstance = null;
    };
    
    try {
      recognitionInstance.start();
    } catch (e: any) {
      console.error("STT: Error during recognitionInstance.start() call:", e);
      options.onError(`Failed to start speech recognition: ${e.message}. Check console for more details.`);
      if (recognitionInstance) {
        try {
          recognitionInstance.abort();
        } catch (abortError) {
            console.warn("STT: Error aborting instance after start() failed:", abortError);
        }
        recognitionInstance = null;
      }
      reject(`Failed to start speech recognition: ${e.message}`);
    }
  });
};

export const stopListening = (): void => {
  if (recognitionInstance) {
    console.log("STT: stopListening() called.");
    try {
        recognitionInstance.stop();
    } catch (e) {
        console.warn("STT: Error calling stop() on recognition instance:", e);
        recognitionInstance = null; 
    }
  } else {
    console.log("STT: stopListening() called, but no active recognition instance.");
  }
};
