
import { GoogleGenAI, Chat, GenerateContentResponse, GroundingChunk, Content, Part } from "@google/genai";
import { ChatMessage, MessageSender } from '../types'; 

let ai: GoogleGenAI | null = null;
let chatSession: Chat | null = null;

const GEMINI_MODEL = 'gemini-2.5-flash-preview-04-17';
export const isApiKeyMissing: boolean = !process.env.API_KEY;

const DEFAULT_SYSTEM_INSTRUCTION = "You are AIVA, an autonomous interactive virtual assistant. You are helpful, polite, and empathetic. When providing information based on web searches, clearly state this and list your sources. Format your responses in Markdown. If you receive an observation about the user's current mood (e.g., '(AIVA observed mood: User seems happy.)'), you MUST acknowledge this directly in your response. For example, if the user seems sad, you should start your response with something like, 'I notice you're looking a bit sad. What happened?' or 'You appear to be [mood]. Is there anything you'd like to talk about?' before addressing their main query. If the user's query is brief or seems related to their mood, you can focus more on their emotional state. Adjust your tone to be supportive and appropriate to the observed mood.";

export function initializeGemini(history?: Content[], systemInstructionOverride?: string): void {
  if (isApiKeyMissing) {
    console.error("Gemini API Key is missing. Cannot initialize AI service.");
    return;
  }
  
  if (!ai) { 
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }

  if(ai){
    const effectiveSystemInstruction = systemInstructionOverride || DEFAULT_SYSTEM_INSTRUCTION;
    chatSession = ai.chats.create({
      model: GEMINI_MODEL,
      history: history || [], 
      config: {
        systemInstruction: effectiveSystemInstruction,
        tools: [{ googleSearch: {} }], 
      },
    });
  } else {
     console.error("GoogleGenAI instance (ai) is not initialized. Cannot create chat session.");
  }
}

export async function AIVAChat(prompt: string): Promise<{ text: string; sources?: {uri: string; title: string}[] }> {
  if (isApiKeyMissing) {
    throw new Error("Gemini API Key is missing.");
  }
  if (!chatSession) {
    console.warn("Chat session not initialized. Attempting to initialize with default history.");
    initializeGemini(); // Initialize with default system prompt
    if (!chatSession) {
        throw new Error("Failed to initialize chat session.");
    }
  }

  try {
    const result: GenerateContentResponse = await chatSession.sendMessage({ message: prompt });
    const responseText = result.text;
    
    let sources: {uri: string; title: string}[] = [];
    const groundingMetadata = result.candidates?.[0]?.groundingMetadata;

    if (groundingMetadata?.groundingChunks && Array.isArray(groundingMetadata.groundingChunks)) {
      sources = groundingMetadata.groundingChunks
        .map((chunk: GroundingChunk) => chunk.web)
        .filter(web => web?.uri && web?.title) 
        .map(web => ({ uri: web!.uri!, title: web!.title! }));
    }
    
    return { text: responseText, sources };
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to get response from AIVA: ${error.message}`);
    }
    throw new Error("Failed to get response from AIVA due to an unknown error.");
  }
}

export function convertMessagesToHistory(messages: ChatMessage[]): Content[] {
  return messages.map(msg => {
    const role: 'user' | 'model' = msg.sender === MessageSender.USER ? 'user' : 'model';
    const parts: Part[] = [{ text: msg.text }];
    return { role, parts };
  });
}
