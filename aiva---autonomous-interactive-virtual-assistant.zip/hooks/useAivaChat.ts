
import { useState, useEffect, useCallback, useRef } from 'react';
import { ChatMessage, MessageSender, GroundingSource, AvatarStyle, UserMood, CameraPermissionStatus, LanguageOption, SUPPORTED_LANGUAGES } from '../types';
import { initializeGemini, AIVAChat, isApiKeyMissing, convertMessagesToHistory } from '../services/geminiService';
import * as sttService from '../services/sttService';
import * as ttsService from '../services/ttsService';
import * as moodDetectionService from '../services/moodDetectionService';

const generateId = (): string => Math.random().toString(36).substr(2, 9);

export const useAivaChat = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [sttError, setSttError] = useState<string | null>(null);
  const [sttTranscript, setSttTranscript] = useState<string>('');
  const [isSttSupportedState, setIsSttSupportedState] = useState<boolean>(false);

  const [isAivaSpeaking, setIsAivaSpeaking] = useState<boolean>(false);
  const [isTtsSupportedState, setIsTtsSupportedState] = useState<boolean>(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceURI, setSelectedVoiceURI] = useState<string | null>(null);

  const [currentAvatarStyle, setCurrentAvatarStyle] = useState<AvatarStyle>('riley'); 
  const [selectedLanguageCode, setSelectedLanguageCode] = useState<string>(SUPPORTED_LANGUAGES[0].code);


  // Mood Detection States
  const [userMood, setUserMood] = useState<UserMood>('neutral');
  const [cameraPermissionStatus, setCameraPermissionStatus] = useState<CameraPermissionStatus>('idle');
  const [isMoodDetectionActive, setIsMoodDetectionActive] = useState<boolean>(false);
  const videoStreamRef = useRef<MediaStream | null>(null);


  useEffect(() => {
    const savedAvatarStyle = localStorage.getItem('aivaAvatarStyle') as AvatarStyle;
    if (savedAvatarStyle && ['alex', 'riley', 'doraemon', 'shizuka'].includes(savedAvatarStyle)) {
      setCurrentAvatarStyle(savedAvatarStyle);
    }
    const savedVoiceURI = localStorage.getItem('aivaSelectedVoiceURI');
    if (savedVoiceURI) {
        setSelectedVoiceURI(savedVoiceURI);
    }
    const savedLangCode = localStorage.getItem('aivaSelectedLangCode');
    if (savedLangCode && SUPPORTED_LANGUAGES.some(lang => lang.code === savedLangCode.toLowerCase())) {
        setSelectedLanguageCode(savedLangCode.toLowerCase());
    } else {
        // If saved lang code is not supported or not present, default to the first supported language
        setSelectedLanguageCode(SUPPORTED_LANGUAGES[0].code);
    }

  }, []);

  useEffect(() => {
    localStorage.setItem('aivaAvatarStyle', currentAvatarStyle);
  }, [currentAvatarStyle]);

  useEffect(() => {
    if (selectedVoiceURI) {
        localStorage.setItem('aivaSelectedVoiceURI', selectedVoiceURI);
    } else {
        localStorage.removeItem('aivaSelectedVoiceURI');
    }
  }, [selectedVoiceURI]);

  useEffect(() => {
    localStorage.setItem('aivaSelectedLangCode', selectedLanguageCode);
  }, [selectedLanguageCode]);


  useEffect(() => {
    setIsSttSupportedState(sttService.isSttSupported());
    setIsTtsSupportedState(ttsService.isTtsSupported());

    if (ttsService.isTtsSupported()) {
      const fetchVoices = () => {
        const voices = ttsService.getVoices();
        if (voices.length > 0) {
          setAvailableVoices(voices);
        }
      };
      fetchVoices();
      if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = fetchVoices;
      }
    }
    
    if (!isApiKeyMissing) {
      const initialMessageText = "Hello! I'm AIVA. How can I assist you today?";
      const welcomeMessage: ChatMessage = {
        id: generateId(),
        text: initialMessageText,
        sender: MessageSender.AIVA,
        timestamp: new Date(),
      };
      setMessages([welcomeMessage]);
      initializeGemini(convertMessagesToHistory([welcomeMessage])); 
    } else {
      setError("Gemini API Key is missing. Please configure it.");
    }

    return () => {
      if (videoStreamRef.current) {
        moodDetectionService.stopVideo(null);
        videoStreamRef.current.getTracks().forEach(track => track.stop());
        videoStreamRef.current = null;
      }
    };
  }, []); 

  const speakText = useCallback((text: string) => {
    if (!ttsService.isTtsSupported() || !text) return;

    let voiceToUse: SpeechSynthesisVoice | undefined = undefined;
    const targetLangNormalized = selectedLanguageCode.toLowerCase();
    const targetLangShortNormalized = targetLangNormalized.split('-')[0];

    const languageFilteredVoices = availableVoices.filter(v => {
        const voiceLangNormalized = v.lang.toLowerCase();
        return voiceLangNormalized.startsWith(targetLangNormalized) || voiceLangNormalized.startsWith(targetLangShortNormalized);
    });

    if (selectedVoiceURI) {
      voiceToUse = languageFilteredVoices.find(v => v.voiceURI === selectedVoiceURI);
    }
    
    if (!voiceToUse) {
        // Character-specific voice preferences (very simplified)
        // Normalize voice names for matching
        if (currentAvatarStyle === 'doraemon') {
            voiceToUse = languageFilteredVoices.find(v => v.name.toLowerCase().includes('child') || v.name.toLowerCase().includes('boy') || v.name.toLowerCase().includes('robot')) ||
                         languageFilteredVoices.find(v => v.default) || languageFilteredVoices[0];
        } else if (currentAvatarStyle === 'shizuka') {
            voiceToUse = languageFilteredVoices.find(v => v.name.toLowerCase().includes('female') && (v.name.toLowerCase().includes('child') || v.name.toLowerCase().includes('girl'))) ||
                         languageFilteredVoices.find(v => v.name.toLowerCase().includes('female') && v.default) ||
                         languageFilteredVoices.find(v => v.name.toLowerCase().includes('female')) || languageFilteredVoices[0];
        } else if (currentAvatarStyle === 'riley') {
            voiceToUse = languageFilteredVoices.find(v => (v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('zira') || v.name.toLowerCase().includes('susan')) && !v.name.toLowerCase().includes('child')) ||
                         languageFilteredVoices.find(v => v.default && v.name.toLowerCase().includes('female')) ||
                         languageFilteredVoices.find(v => v.name.toLowerCase().includes('female')) || languageFilteredVoices[0];
        } else if (currentAvatarStyle === 'alex') {
            voiceToUse = languageFilteredVoices.find(v => (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('david') || v.name.toLowerCase().includes('mark')) && !v.name.toLowerCase().includes('child')) ||
                         languageFilteredVoices.find(v => v.default && v.name.toLowerCase().includes('male')) ||
                         languageFilteredVoices.find(v => v.name.toLowerCase().includes('male')) || languageFilteredVoices[0];
        }
    }
    
    // Fallback if no specific voice found for character/language combo
    if (!voiceToUse && languageFilteredVoices.length > 0) {
        voiceToUse = languageFilteredVoices.find(v => v.default) || languageFilteredVoices[0];
    } else if (!voiceToUse && availableVoices.length > 0) { // Ultimate fallback to any available voice
        voiceToUse = availableVoices.find(v => v.default && v.lang.toLowerCase().startsWith(targetLangShortNormalized)) || 
                     availableVoices.find(v => v.lang.toLowerCase().startsWith(targetLangShortNormalized)) || 
                     availableVoices[0];
    }


    ttsService.speak(
      text,
      () => setIsAivaSpeaking(true),
      () => setIsAivaSpeaking(false),
      (errMsg) => {
        console.error("TTS Error from hook:", errMsg);
        setIsAivaSpeaking(false);
      },
      voiceToUse?.voiceURI,
      targetLangNormalized // Pass normalized target language to TTS service
    );
  }, [selectedVoiceURI, availableVoices, currentAvatarStyle, selectedLanguageCode]);


  const startRecording = useCallback(async () => {
    if (!sttService.isSttSupported()) {
      setSttError("Speech recognition is not supported in your browser.");
      return;
    }
    ttsService.cancel();
    setIsAivaSpeaking(false);
    setSttError(null);
    setSttTranscript('');
    setIsRecording(true);
    try {
      await sttService.startListening({
        onResult: (transcript, isFinal) => {
          setSttTranscript(transcript);
          if (isFinal) {
            setIsRecording(false); 
          }
        },
        onError: (errMsg) => {
          setSttError(errMsg);
          setIsRecording(false);
        },
        onEnd: () => {
          setIsRecording(false);
        },
        onStart: () => {
           setSttError(null);
        },
        lang: selectedLanguageCode // Use selected language for STT
      });
    } catch (err: any) {
        setSttError(err.message || "Failed to start recording.");
        setIsRecording(false);
    }
  }, [selectedLanguageCode]);

  const stopRecording = useCallback(() => {
    if (isRecording) { 
      sttService.stopListening();
      setIsRecording(false);
    }
  }, [isRecording]);

  const sendMessage = useCallback(async (text: string) => {
    if (isApiKeyMissing) {
      setError("Cannot send message: Gemini API Key is missing.");
      return;
    }
    if (!text.trim()) return;

    ttsService.cancel();
    setIsAivaSpeaking(false);

    const userMessage: ChatMessage = {
      id: generateId(),
      text,
      sender: MessageSender.USER,
      timestamp: new Date(),
    };

    setMessages(prevMessages => [...prevMessages, userMessage]);
    setIsLoading(true);
    setError(null);
    setSttTranscript('');

    let promptToSend = text;
    if ((currentAvatarStyle === 'alex' || currentAvatarStyle === 'riley') && isMoodDetectionActive && userMood && userMood !== 'neutral') {
      const moodPrefix = `(AIVA observed mood: User seems ${userMood}.) `;
      promptToSend = `${moodPrefix}${text}`;
    }

    try {
      const currentHistory = convertMessagesToHistory([...messages, {...userMessage, text: promptToSend}]);
      let systemInstructionOverride = undefined;
      if (currentAvatarStyle === 'doraemon') {
        systemInstructionOverride = "You are Doraemon, a helpful robotic cat from the future. Respond in a friendly, encouraging, and slightly whimsical way. You are very knowledgeable but also playful. Keep responses concise and easy to understand for a general audience. You should not refer to yourself as AIVA.";
      } else if (currentAvatarStyle === 'shizuka') {
        systemInstructionOverride = "You are Shizuka, a kind, intelligent, and polite girl. Respond in a gentle, caring, and thoughtful manner. You are very understanding and supportive. You should not refer to yourself as AIVA.";
      }
      
      initializeGemini(currentHistory, systemInstructionOverride); 
      
      const aiResponse = await AIVAChat(promptToSend);

      const aivaMessage: ChatMessage = {
        id: generateId(),
        text: aiResponse.text,
        sender: MessageSender.AIVA,
        timestamp: new Date(),
        sources: aiResponse.sources,
      };
      setMessages(prevMessages => [...prevMessages, aivaMessage]);
      if (aiResponse.text) speakText(aiResponse.text);
    } catch (e: any) {
      console.error("Failed to send message or get AI response:", e);
      const errorMessageText = e.message || "An error occurred while communicating with AIVA.";
      setError(errorMessageText);
      const errorChatMessage: ChatMessage = {
        id: generateId(),
        text: `Sorry, I encountered an error: ${errorMessageText}. Please try again.`,
        sender: MessageSender.AIVA,
        timestamp: new Date(),
      };
      setMessages(prevMessages => [...prevMessages, errorChatMessage]);
      if (errorChatMessage.text) speakText(errorChatMessage.text);
    } finally {
      setIsLoading(false);
    }
  }, [messages, speakText, isApiKeyMissing, isMoodDetectionActive, userMood, currentAvatarStyle]); 

  const clearChat = useCallback(() => {
    if (isApiKeyMissing) {
        setError("Cannot clear chat: Gemini API Key is missing.");
        return;
    }
    ttsService.cancel();
    setIsAivaSpeaking(false);
    const clearedMessageText = "Chat cleared. How can I assist you now?";
    const clearedMessage: ChatMessage = {
      id: generateId(),
      text: clearedMessageText,
      sender: MessageSender.AIVA,
      timestamp: new Date(),
    };
    setMessages([clearedMessage]);
    
    let systemInstructionOverride = undefined;
    if (currentAvatarStyle === 'doraemon') {
      systemInstructionOverride = "You are Doraemon, a helpful robotic cat from the future. Respond in a friendly, encouraging, and slightly whimsical way. Keep responses concise. You should not refer to yourself as AIVA.";
    } else if (currentAvatarStyle === 'shizuka') {
      systemInstructionOverride = "You are Shizuka, a kind, intelligent, and polite girl. Respond in a gentle, caring, and thoughtful manner. You should not refer to yourself as AIVA.";
    }
    initializeGemini(convertMessagesToHistory([clearedMessage]), systemInstructionOverride);

    setError(null);
    setSttTranscript('');
    setSttError(null);
    if (clearedMessageText) speakText(clearedMessageText);
  }, [speakText, isApiKeyMissing, currentAvatarStyle]); 

  const playMessageAudio = useCallback((text: string) => {
    if (text) speakText(text);
  }, [speakText]);
  
  const cancelTts = useCallback(() => {
    ttsService.cancel();
    setIsAivaSpeaking(false);
  },[]);

  const changeAvatarStyle = useCallback((style: AvatarStyle) => {
    setCurrentAvatarStyle(style);
    const lastMessage = messages.length > 0 ? messages[messages.length-1] : {id: generateId(), text: "Hello!", sender: MessageSender.AIVA, timestamp: new Date()};
    let systemInstructionOverride = undefined;
    if (style === 'doraemon') {
      systemInstructionOverride = "You are Doraemon, a helpful robotic cat from the future. Respond in a friendly, encouraging, and slightly whimsical way. Keep responses concise. You should not refer to yourself as AIVA.";
    } else if (style === 'shizuka') {
      systemInstructionOverride = "You are Shizuka, a kind, intelligent, and polite girl. Respond in a gentle, caring, and thoughtful manner. You should not refer to yourself as AIVA.";
    }
    initializeGemini(convertMessagesToHistory([lastMessage]), systemInstructionOverride);

  }, [messages]);

  const changeVoice = useCallback((voiceURI: string | null) => {
    setSelectedVoiceURI(voiceURI);
  }, []);

  const changeLanguage = useCallback((langCode: string) => {
    setSelectedLanguageCode(langCode.toLowerCase());
    setSelectedVoiceURI(null); 
  }, []);

  const toggleMoodDetection = useCallback(async (videoElement: HTMLVideoElement | null) => {
    if (currentAvatarStyle !== 'alex' && currentAvatarStyle !== 'riley') {
        if(isMoodDetectionActive){ 
            moodDetectionService.stopVideo(videoElement);
            if (videoStreamRef.current) { videoStreamRef.current.getTracks().forEach(track => track.stop()); videoStreamRef.current = null; }
            setIsMoodDetectionActive(false); setUserMood('neutral'); setCameraPermissionStatus('idle');
        }
        return; 
    }

    if (isMoodDetectionActive) {
      moodDetectionService.stopVideo(videoElement);
      if (videoStreamRef.current) { videoStreamRef.current.getTracks().forEach(track => track.stop()); videoStreamRef.current = null; }
      setIsMoodDetectionActive(false); setUserMood('neutral'); setCameraPermissionStatus('idle'); 
    } else {
      if (!videoElement) { console.error("Video element not for mood detection."); setCameraPermissionStatus('denied'); return; }
      setCameraPermissionStatus('pending');
      const permissionResult = await moodDetectionService.requestCameraPermission();
      setCameraPermissionStatus(permissionResult.status);

      if (permissionResult.status === 'granted' && permissionResult.stream) {
        videoStreamRef.current = permissionResult.stream;
        moodDetectionService.startVideo(videoElement, setUserMood, permissionResult.stream);
        setIsMoodDetectionActive(true);
      } else {
        setIsMoodDetectionActive(false);
        if (videoStreamRef.current) { videoStreamRef.current.getTracks().forEach(track => track.stop()); videoStreamRef.current = null; }
      }
    }
  }, [isMoodDetectionActive, currentAvatarStyle]);


  return {
    messages, sendMessage, isLoading, error, clearChat,
    isRecording, startRecording, stopRecording, sttError, setSttError, sttTranscript, setSttTranscript, isSttSupported: isSttSupportedState,
    playMessageAudio, cancelTts, isTtsSupported: isTtsSupportedState, isAivaSpeaking,
    currentAvatarStyle, changeAvatarStyle, 
    availableVoices, selectedVoiceURI, changeVoice,
    selectedLanguageCode, changeLanguage, availableLanguages: SUPPORTED_LANGUAGES, 
    userMood, cameraPermissionStatus, isMoodDetectionActive, toggleMoodDetection,
  };
};